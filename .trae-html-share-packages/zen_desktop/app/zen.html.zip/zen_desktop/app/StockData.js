

class StockData {
    WSClient = null;
    ID = Guid();

    RequestStockData_ID = `${this.ID}-RequestStockData`;
    RequestReportStockListData_ID = `${this.ID}-RequestReportStockListData`;

    RequestMinuteData_ID = `${this.ID}-RequestMinuteData`;

    RequestKLineData_ID = `${this.ID}-Request-KLineData`;
    RequestKLineRealtimeData_ID = `${this.ID}-Request-KLineData`;

    RequestKLineMinuteData_ID = `${this.ID}-Request-KLineData`;
    RequestKLineMinuteRealtimeData_ID = `${this.ID}-Request-KLineData`;
    RequestKLineFlowCapitalData_ID = `${this.ID}-FlowCapitalData`;

    RequestDealData_ID = `${this.ID}-Request-DealData`;

    RequestStockInfoData_ID = `${this.ID}-RequestStockInfoData`;

    RequestTReportListData_ID = `${this.ID}-RequestTReportListData`;
    RequestTReportStockData_ID = `${this.ID}-RequestTReportStockData`;

    Counter = 1;

    // === K线数据本地缓存 ===
    // key: symbol_period_right -> { Data: [kItem...], Time: ms }
    // 全量请求（取最新 count 根）需最新数据 → TTL 内才命中；
    // 历史范围请求（Range.End 之前 count 根）数据不可变 → 无 TTL，缓存覆盖即命中。
    KLineCache = new Map();
    KLineCacheTTL = 60000;              // 全量命中窗口(ms)：窗口内最后一根可能过期，由 AutoUpdate 实时轮询修正
    KLineCacheMax = 48;                 // 最多缓存 (symbol,period,right) 组合数，超限 FIFO 淘汰
    AbnormalDayBarMin = 10;             // 日/周/月/年线（周期<=3）正常根数下限，低于视为异常响应
    AbnormalMinuteBarMin = 2;           // 分钟线（周期>=4）正常根数下限，低于视为异常响应
    KLineReqSeq = 0;                    // K线请求序号：响应按完成序送达，序号落后的过期响应丢弃，
                                       // 防止快切周期时旧响应（如初始420根）后到覆盖新数据

    IsDayPeriod(period) {
        return typeof period === 'number' && period <= 3;
    }

    // kItem 的时间键：分钟线组合 Date*10000+Time，否则 Date
    KLineTimeKey(kItem, isMinute) {
        return isMinute && kItem[8] != null ? (kItem[0] * 10000 + kItem[8]) : kItem[0];
    }

    KLineCacheKey(symbol, period, right) {
        return `${symbol}_${period}_${right || 0}`;
    }

    // 查询缓存：请求 rangeEnd 之前（含）的 count 根；rangeEnd 为空表示取最新 count 根
    // 返回命中的 kItem 数组切片，未命中返回 null
    KLineCacheGet(symbol, period, right, count, rangeEnd) {
        var entry = this.KLineCache.get(this.KLineCacheKey(symbol, period, right));
        if (!entry || !entry.Data || entry.Data.length === 0) return null;
        var data = entry.Data;
        var isMinute = !this.IsDayPeriod(period);
        if (rangeEnd != null) {
            // 历史数据不可变：无 TTL，判断缓存是否覆盖 [rangeEnd-count+1, rangeEnd] 范围
            var endIdx = -1;
            for (var i = data.length - 1; i >= 0; --i) {
                if (this.KLineTimeKey(data[i], isMinute) <= rangeEnd) { endIdx = i; break; }
            }
            if (endIdx < 0) return null;
            if (endIdx - count + 1 < 0) return null;   // 缓存左侧不够长，未覆盖请求范围
            return data.slice(endIdx - count + 1, endIdx + 1);
        }
        // 全量：需要最新数据，TTL 外视为过期
        if (Date.now() - entry.Time > this.KLineCacheTTL) return null;
        if (data.length < count) return null;
        return data.slice(data.length - count);
    }

    // 写缓存前的数据正确性校验：数量下限 + 时间严格升序（乱序/重复=坏响应，拒绝缓存）
    KLineDataValid(period, aryData) {
        if (!aryData || aryData.length === 0) return false;
        var minCount = this.IsDayPeriod(period) ? this.AbnormalDayBarMin : this.AbnormalMinuteBarMin;
        if (aryData.length < minCount) return false;
        var isMinute = !this.IsDayPeriod(period);
        for (var i = 1; i < aryData.length; ++i) {
            if (!(this.KLineTimeKey(aryData[i - 1], isMinute) < this.KLineTimeKey(aryData[i], isMinute))) return false;
        }
        return true;
    }

    KLineCachePut(symbol, period, right, aryData) {
        // 仅正确的数据入缓存：数量过少或时间乱序的坏响应拒绝缓存，
        // 否则坏数据被缓存后挡住上层自动重试（重试命中坏缓存形成死循环）
        if (!this.KLineDataValid(period, aryData)) return;
        // 存副本：与传给 HQChart 的数组隔离，防止下游修改污染缓存
        this.KLineCache.set(this.KLineCacheKey(symbol, period, right), { Data: aryData.slice(), Time: Date.now() });
        while (this.KLineCache.size > this.KLineCacheMax) {
            this.KLineCache.delete(this.KLineCache.keys().next().value);
        }
    }

    NetworkFilter(data, callback, option) {
        console.log(`[StockData::NetworkFilter] ${data.Name} - ${data.Explain}`);

        switch (data.Name) {
            //////////////////////////////////////////////////////
            //报价列表数据
            case "JSReportChartContainer::RequestStockListData":
                //HQChart使用教程95-报价列表对接第3方数据1-码表数据
                this.Report_RequestStockListData(data, callback, option);             //码表
                break;
            case "JSReportChartContainer::RequestMemberListData":                           //板块成分
                //HQChart使用教程95-报价列表对接第3方数据2-板块成分数据
                this.Report_RequestMemberListData(data, callback, option);
                break;
            case "JSDealChartContainer::RequestStockData":                  //股票数据更新
                //HQChart使用教程95-报价列表对接第3方数据3-股票数据
                this.Report_RequestStockData(data, callback, option);
                break;
            case "MinuteChartContainer::RequestPopMinuteData":          //弹出分时图数据
                //HQChart使用教程29-走势图如何对接第3方数据2-最新分时数据  格式跟这个一样
                this.Report_RequestPopMinuteData(data, callback, option);
                break;

            /////////////////////////////////////////////////////////////////////
            //走势图 HQChart使用教程29-走势图如何对接第3方数据1
            case 'MinuteChartContainer::RequestMinuteData':                 //分时图数据对接
                //HQChart使用教程29-走势图如何对接第3方数据2-最新分时数据
                this.Minute_RequestMinuteData(data, callback, option);
                break;
            case "MinuteChartContainer::RequestOverlayMinuteData":          //单日叠加
                //HQChart使用教程29-走势图如何对接第3方数据7-叠加股票最新分时数据
                this.Minute_RequestOverlayMinuteData(data, callback, option);
                break;


            /////////////////////////////////////////////////////////////
            //K线图
            case 'KLineChartContainer::RequestHistoryData':                 //日线全量数据下载
                //HQChart使用教程30-K线图如何对接第3方数据2-日K数据
                this.KLine_RequestHistoryData(data, callback, option);
                break;

            case 'KLineChartContainer::RequestRealtimeData':                //日线实时数据更新
                //HQChart使用教程30-K线图如何对接第3方数据14-轮询增量更新日K数据
                this.KLine_RequestRealtimeData(data, callback, option);
                break;

            case 'KLineChartContainer::ReqeustHistoryMinuteData':           //分钟全量数据下载
                //HQChart使用教程30-K线图如何对接第3方数据3-1分钟K数据
                this.KLine_RequestHistoryMinuteData(data, callback, option);
                break;

            case 'KLineChartContainer::RequestMinuteRealtimeData':          //分钟增量数据更新
                //HQChart使用教程30-K线图如何对接第3方数据15-轮询增量更新1分钟K线数据
                this.KLine_RequestMinuteRealtimeData(data, callback, option);
                break;

            case "KLineChartContainer::RequestOverlayHistoryData":      //叠加股票日线
                //HQChart使用教程30-K线图如何对接第3方数据16-日K叠加股票
                this.KLine_RequestOverlayHistoryData(data, callback, option);
                break;

            case "KLineChartContainer::RequestOverlayHistoryMinuteData":
                //HQChart使用教程30-K线图如何对接第3方数据17- 分钟K叠加股票
                this.KLine_RequestOverlayHistoryMinuteData(data, callback, option);
                break;

            case 'KLineChartContainer::RequestFlowCapitalData':             //流通股本
                //HQChart使用教程30-K线图如何对接第3方数据4-流通股本数据
                this.KLine_RequestFlowCapitalData(data, callback, option);
                break;

            case 'KLineChartContainer::RequestDragDayData':                  //拖拽日K数据下载
            case 'KLineChartContainer::RequestZoomDayData':                  //缩放日K数据下载
                this.KLine_RequestPreviousDayData(data, callback, option);
                break;

            case 'KLineChartContainer::RequestDragMinuteData':               //拖拽分钟K数据下载
            case 'KLineChartContainer::RequestZoomMinuteData':               //缩放分钟K数据下载
                this.KLine_RequestPreviousMinuteData(data, callback, option);
                break;

            case "JSSymbolData::GetIndexData":
                //HQChart使用教程30-K线图如何对接第3方数据28-大盘数据[INDEXA,INDEXC......]
                this.KLine_INDEX_RequestData(data, callback, option);
                break;
            case "JSSymbolData::GetLatestData":
                //HQChart使用教程30-K线图如何对接第3方数据30-即时行情数据DYNAINFO
                this.KLine_RequestLatestData(data, callback, option);
                break;

            case "JSSymbolData::GetOtherSymbolData":
                //HQChart使用教程30-K线图如何对接第3方数据31-获取指定品种的K线数据
                this.KLine_RequestOtherSymbolData(data, callback, option);
                break;
            case 'JSSymbolData::GetSymbolData':
                //HQChart使用教程30-K线图如何对接第3方数据38-通达信指标K线数据
                this.KLine_RequestSymbolData(data, callback, option);        //计算指标需要的K线数据
                break;

            case "JSSymbolData::GetVariantData":                            //额外的变量数据
                //HQChart使用教程30-K线图如何对接第3方数据29-板块字符串函数数据[GNBLOCK,GNBLOCKNUM......]
                this.KLine_RequestVariantData(data, callback, option);
                break;
            case "JSSymbolData::GetFinance":    //财务数据
                //HQChart使用教程30-K线图如何对接第3方数据23- FINANCE函数数据
                this.KLine_RequestFinanceData(data, callback, option);
                break;

            /////////////////////////////////////////////////////////////////////////////////////
            //成交明细
            case 'JSDealChartContainer::RequestDealData':               //全量数据下载
                this.Deal_RequestHistoryData(data, callback, option);
                break;
            case "JSDealChartContainer::RequestDealUpdateData":
                this.Deal_RequestUpdateData(data, callback, option);
                break;

            ////////////////////////////////////////////////////////////////////////////
            // 5档买卖
            case "JSStockInfoChartContainer::RequestStockData":
                this.StockInfo_RequestStockData(data, callback, option);
                break;


            ////////////////////////////////////////////////////////////////////////////
            // 底部状态栏
            case "JSStatusBarChartContainer::RequestStockData":
                this.StatusBar_RequestStockData(data, callback, option);
                break;

            /////////////////////////////////////////////////////////////////////////////
            //T型报价
            case "JSTReportChartContainer::RequestStockListData":
                this.TReport_RequestStockListData(data, callback, option);             //T型报价列表
                break;
            case "JSTReportChartContainer::RequestStockData":          //T型报价数据更新
                this.TReport_RequestStockData(data, callback, option);
                break;
        }
    }

    //空码表
    Report_RequestStockListData_Empty(data, callback, option) {
        data.PreventDefault = true;
        var hqchartData = { data: [] };
        console.log("[StockData.Report_RequestStockListData_EMPTY] hqchartData", hqchartData);
        callback(hqchartData);
    }

    Report_RequestStockListData_Full(data, callback, option) {
        data.PreventDefault = true;
        var requestID = this.RequestReportStockListData_ID;
        var extendID = this.Counter++;

        var msg =
        {
            MessageID: 3,
            Data:
            {
                Type: 7, ID: requestID,
                AryMarket: [], ExtendData: { ExtendID: extendID },
            }
        };

        var callbackInfo =
        {
            ID: requestID,
            ExtendID: extendID,
            Callback: (recv) => {
                this.Report_RecvStockListData_Full(recv, callback, option);
            }
        }

        this.WSClient.Request(msg, callbackInfo);
    }

    Report_RecvStockListData_Full(recv, callback, option) {
        var hqchartData = { data: [] };
        if (IFrameSplitOperator.IsNonEmptyArray(recv.AryData)) {
            for (var i = 0; i < recv.AryData.length; ++i) {
                var item = recv.AryData[i];
                var newItem = [item.Symbol, item.Name];
                hqchartData.data.push(newItem);

                if (option && option.AryData) option.AryData.push(item);
            }
        }

        callback(hqchartData);
    }

    Report_RequestStockListData(data, callback, option) {
        if (option && option.ChartName == "FullReportChart") {
            this.Report_RequestStockListData_Full(data, callback, option);
        }
        else {
            this.Report_RequestStockListData_Empty(data, callback, option);
        }
    }



    //板块|行业等成分列表
    Report_RequestMemberListData(data, callback, option) {
        var symbol = data.Request.Data.symbol;    //板块代码
        data.PreventDefault = true;

        var hqchartData = { symbol: symbol, name: symbol, data: [], code: 0 };
        if (this.MapSelfBlcok.has(symbol)) {
            var item = this.MapSelfBlcok.get(symbol);
            hqchartData.data = item.ArySymbol.slice();
        }

        callback(hqchartData);
    }

    Report_RequestStockData(data, callback, option) {
        var aryStock = data.Request.Data.stocks;    //股票列表
        var blockSymbol = data.Request.symbol;
        data.PreventDefault = true;

        if (blockSymbol == "SZSH_HK_STOCK")   //A+H股
        {
            this.Report_RequestStockData_SZSH_HK(data, callback, option);
            return;
        }

        var bMinuteLine = false, kLineConfig = null;
        var reportCtrl = data.Self;
        var reportChart = reportCtrl.GetReportChart();
        if (reportChart && IFrameSplitOperator.IsNonEmptyArray(reportChart.Column)) {
            for (var i = 0; i < reportChart.Column.length; ++i) {
                var item = reportChart.Column[i];
                if (item.Type == REPORT_COLUMN_ID.CLOSE_LINE_ID)   //收盘线
                    bMinuteLine = true;
                else if (item.Type == REPORT_COLUMN_ID.KLINE_ID) //K线
                    kLineConfig = { Period: 0, Right: 0, Count: 20 };
            }
        }

        if (option) option.Report = data.Self;


        var arySymbol = [];
        for (var i = 0; i < aryStock.length; ++i) {
            arySymbol.push({ Symbol: aryStock[i].Symbol, Fields: { MinuteClose: bMinuteLine, KLine: kLineConfig } }); //MinuteClose=走势图线 KLine=k线图
        }

        var extendID = this.Counter++;

        var msg =
        {
            MessageID: 3,
            Data:
            {
                Type: 1,
                ID: this.RequestStockData_ID,
                ArySymbol: arySymbol,
                ExtendData: { ExtendID: extendID },
            }
        };

        var callbackInfo =
        {
            ID: this.RequestStockData_ID,
            ExtendID: extendID,
            Callback: (recv) => {
                this.Report_RecvStockData(recv, callback, option);
            }
        }

        this.WSClient.Request(msg, callbackInfo);
    }

    Report_RecvStockData(recv, callback, option) {
        var hqchartData = { data: [], code: 0 };
        var report = null;
        if (option && option.Report) report = option.Report;

        function __Temp_CheckPriceChange(symbol, price, filedName, colID) {
            if (!symbol || !IFrameSplitOperator.IsNumber(price)) return false;
            if (!report) return false;
            if (!report.MapStockData.has(symbol)) return false;
            var stockItem = report.MapStockData.get(symbol);
            var value = stockItem[filedName]
            if (!IFrameSplitOperator.IsNumber(value)) return false;
            if (price === value) return false;

            var flashData = { ID: colID, Color: null, Count: 1 }; //4=最新价
            if (price > value) flashData.Color = "rgba(205,92,92,0.4)";
            else flashData.Color = "rgba(46,139,87,0.4)";

            report.SetFlashBGItem(symbol, flashData);
        }

        if (IFrameSplitOperator.IsNonEmptyArray(recv.AryData)) {
            for (var i = 0; i < recv.AryData.length; ++i) {
                var stockItem = recv.AryData[i];
                var item = [];
                item[0] = stockItem.Symbol;

                item[1] = stockItem.Name;               //名称
                item[2] = stockItem.YClose;             //昨收
                item[3] = stockItem.Open;               //今开
                item[4] = stockItem.High;               //最高
                item[5] = stockItem.Low;                //最低
                item[6] = stockItem.Close;              //最新价
                item[7] = stockItem.Vol;                //成交量
                item[8] = stockItem.Amount;             //成交额
                item[9] = stockItem.BidPrice;           //买一价
                item[11] = stockItem.AskPrice;          //卖一价
                item[35] = stockItem.Time;               //时间
                item[36] = stockItem.Date;               //日期

                item[21] = stockItem.Increase;           //涨幅%
                item[22] = stockItem.UpDown;             //涨跌
                item[24] = stockItem.Amplitude;          //振幅%

                item[38] = stockItem.Position;           //持仓量
                item[39] = stockItem.FClose;             //结算价
                item[40] = stockItem.YFClose;            //昨结算价

                if (IFrameSplitOperator.IsNumber(stockItem.DeliveryDate)) item[48] = stockItem.DeliveryDate;
                if (IFrameSplitOperator.IsNumber(stockItem.OpenDate)) item[49] = stockItem.OpenDate;
                if (IFrameSplitOperator.IsNumber(stockItem.ExpireDate)) item[50] = stockItem.ExpireDate;

                __Temp_CheckPriceChange(stockItem.Symbol, stockItem.Close, "Price", REPORT_COLUMN_ID.PRICE_ID);
                __Temp_CheckPriceChange(stockItem.Symbol, stockItem.BidPrice, "BuyPrice", REPORT_COLUMN_ID.BUY_PRICE_ID);
                __Temp_CheckPriceChange(stockItem.Symbol, stockItem.AskPrice, "SellPrice", REPORT_COLUMN_ID.SELL_PRICE_ID);

                if (stockItem.Minute)   //分时图
                {
                    var minData = stockItem.Minute;
                    var minMaxCount = 242;

                    var aryTime = JSChart.GetMinuteTimeStringData().GetTimeData(stockItem.Symbol);
                    if (IFrameSplitOperator.IsNonEmptyArray(aryTime)) minMaxCount = aryTime.length;

                    var newData = { Data: minData.AryClose, Max: null, Min: null, Count: Math.max(minMaxCount, minData.AryClose.length), YClose: minData.YClose };
                    for (var j = 0; j < newData.Data.length; ++j) {
                        var value = newData.Data[j];
                        if (newData.Max == null || newData.Max < value) newData.Max = value;
                        if (newData.Min == null || newData.Min > value) newData.Min = value;
                    }

                    item[32] = newData;
                }

                if (stockItem.KLine) //K线图
                {
                    var kData = stockItem.KLine;
                    var newData = { AryData: [] };
                    for (var j = 0; j < kData.Data.length; ++j) {
                        var kItem = kData.Data[j];
                        newData.AryData.push([kItem.Open, kItem.High, kItem.Low, kItem.Close]);
                    }
                    item[33] = newData;
                }


                hqchartData.data.push(item);
            }
        }

        callback(hqchartData);
    }


    //A+H股
    Report_RequestStockData_SZSH_HK(data, callback, option) {
        var aryStock = data.Request.Data.stocks;    //股票列表
        data.PreventDefault = true;
        var mapStock = option.MapSHSZ_HK;

        var arySymbol = [];
        for (var i = 0; i < aryStock.length; ++i) {
            var symbol = aryStock[i].Symbol;
            arySymbol.push({ Symbol: symbol });
            if (mapStock && mapStock.has(symbol)) {
                arySymbol.push({ Symbol: mapStock.get(symbol).HK.Symbol });
            }
        }

        if (option) option.Report = data.Self;
        var extendID = this.Counter++;
        var msg =
        {
            MessageID: 3,
            Data:
            {
                Type: 1,
                ID: this.RequestStockData_ID,
                ArySymbol: arySymbol,
                ExtendData: { ExtendID: extendID },
            }
        };

        var callbackInfo =
        {
            ID: this.RequestStockData_ID,
            ExtendID: extendID,
            Callback: (recv) => {
                this.Report_RecvStockData_SZSH_HK(recv, callback, option);
            }
        }

        this.WSClient.Request(msg, callbackInfo);
    }


    Report_RecvStockData_SZSH_HK(recv, callback, option) {
        var hqchartData = { data: [], code: 0 };
        var report = null;
        if (option && option.Report) report = option.Report;
        var mapSHSZHK = option.MapSHSZ_HK;

        function __Temp_CheckPriceChange(symbol, price, filedName, colID) {
            if (!symbol || !IFrameSplitOperator.IsNumber(price)) return false;
            if (!report) return false;
            if (!report.MapStockData.has(symbol)) return false;
            var stockItem = report.MapStockData.get(symbol);
            var value = stockItem[filedName]
            if (!IFrameSplitOperator.IsNumber(value)) return false;
            if (price === value) return false;

            var flashData = { ID: colID, Color: null, Count: 1 }; //4=最新价
            if (price > value) flashData.Color = "rgba(205,92,92,0.4)";
            else flashData.Color = "rgba(46,139,87,0.4)";

            report.SetFlashBGItem(symbol, flashData);
        }

        var mapStock = new Map();
        if (IFrameSplitOperator.IsNonEmptyArray(recv.AryData)) {
            for (var i = 0; i < recv.AryData.length; ++i) {
                var stockItem = recv.AryData[i];
                var upperSymbol = stockItem.Symbol.toUpperCase();
                if (MARKET_SUFFIX_NAME.IsHK(upperSymbol)) continue;

                var item = [];
                item[0] = stockItem.Symbol;
                item[1] = stockItem.Name;               //名称
                item[2] = stockItem.YClose;             //昨收
                item[3] = stockItem.Open;               //今开
                item[4] = stockItem.High;               //最高
                item[5] = stockItem.Low;                //最低
                item[6] = stockItem.Close;              //最新价
                item[7] = stockItem.Vol;                //成交量
                item[8] = stockItem.Amount;             //成交额
                item[9] = stockItem.BidPrice;           //买一价
                item[11] = stockItem.AskPrice;          //卖一价
                item[35] = stockItem.Time;               //时间
                item[36] = stockItem.Date;               //日期

                item[21] = stockItem.Increase;           //涨幅%
                item[22] = stockItem.UpDown;             //涨跌
                item[24] = stockItem.Amplitude;          //振幅%

                __Temp_CheckPriceChange(stockItem.Symbol, stockItem.Close, "Price", REPORT_COLUMN_ID.PRICE_ID);
                __Temp_CheckPriceChange(stockItem.Symbol, stockItem.BidPrice, "BuyPrice", REPORT_COLUMN_ID.BUY_PRICE_ID);
                __Temp_CheckPriceChange(stockItem.Symbol, stockItem.AskPrice, "SellPrice", REPORT_COLUMN_ID.SELL_PRICE_ID);

                if (mapSHSZHK.has(stockItem.Symbol)) {
                    var shsz_hk = mapSHSZHK.get(stockItem.Symbol);
                    item[201] = MARKET_SUFFIX_NAME.GetShortSymbol(shsz_hk.HK.Symbol);
                    item[202] = shsz_hk.HK.Name;
                }

                mapStock.set(stockItem.Symbol, item);
            }

            for (var i = 0; i < recv.AryData.length; ++i) {
                var stockItem = recv.AryData[i];
                var upperSymbol = stockItem.Symbol.toUpperCase();
                if (!MARKET_SUFFIX_NAME.IsHK(upperSymbol)) continue;
                if (!mapSHSZHK.has(stockItem.Symbol)) continue;

                var shsz_hk = mapSHSZHK.get(stockItem.Symbol);
                if (!mapStock.has(shsz_hk.SHSZ.Symbol)) continue;

                var item = mapStock.get(shsz_hk.SHSZ.Symbol);
                item[202] = stockItem.Name;
                item[203] = IFrameSplitOperator.FormatDateString(stockItem.Date, "YYYY-MM-DD");           //日期
                item[204] = IFrameSplitOperator.FormatTimeString(stockItem.Time, "HH:MM:SS")              //时间

                item[101] = stockItem.Increase;
                item[102] = { Value: stockItem.Close, CompareValue: stockItem.YClose };
                item[103] = stockItem.UpDown;


            }

            for (var mapItem of mapStock) {
                hqchartData.data.push(mapItem[1]);
            }
        }

        callback(hqchartData);
    }


    Report_RequestPopMinuteData(data, callback, option) {
        data.PreventDefault = true;
        var symbol = data.Request.Data.symbol[0];             //请求的股票代码
        var date = data.Request.Data.date;                    //PopMinuteChart 设置的指定日期

        if (option) {
            option.HQChart = data.Self;
            option.Symbol = symbol;
        }

        var extendID = this.Counter++;

        var msg =
        {
            MessageID: 3,
            Data:
            {
                Type: 3,
                ID: this.RequestMinuteData_ID,
                ArySymbol: [{ Symbol: symbol, Date: date }],
                ExtendData: { ExtendID: extendID },
            }
        };

        var callbackInfo =
        {
            ID: this.RequestMinuteData_ID,
            ExtendID: extendID,
            Callback: (recv) => {
                this.Minute_RecvMinuteData(recv, callback, option);
            }
        }

        this.WSClient.Request(msg, callbackInfo);
    }


    //单日分时图
    Minute_RequestMinuteData(data, callback, option) {
        data.PreventDefault = true;
        var symbol = data.Request.Data.symbol[0];             //请求的股票代码
        console.log(`[StockData::Minute_RequestMinuteData] Symbol=${symbol}, Update=${data.Self.DataStatus.LatestDay}`);

        if (option) {
            option.HQChart = data.Self;
            option.Symbol = symbol;
        }

        var extendID = this.Counter++;
        var bCache = false;
        if (data.PopData) bCache = true;

        var msg =
        {
            MessageID: 3,
            Data:
            {
                Type: 3,
                ID: this.RequestMinuteData_ID,
                ArySymbol: [{ Symbol: symbol, Cache: bCache }],
                ExtendData: { ExtendID: extendID },
            }
        };

        var callbackInfo =
        {
            ID: this.RequestMinuteData_ID,
            ExtendID: extendID,
            Callback: (recv) => {
                this.Minute_RecvMinuteData(recv, callback, option);
            }
        }

        this.WSClient.Request(msg, callbackInfo);
    }


    Minute_RecvMinuteData(recv, callback, option) {
        var hqchartData = { code: 0, stock: [] };
        var hqchart = null;
        if (option && option.HQChart) hqchart = option.HQChart;

        if (!recv || !Array.isArray(recv.AryData)) {
            if (recv && recv.Error) console.error(`[StockData::Minute_RecvMinuteData] Recv error:`, recv.Error);
            callback(hqchartData);
            return;
        }

        var symbol = (option && option.Symbol) ? option.Symbol : (hqchart ? hqchart.Symbol : null);

        for (var i = 0; i < recv.AryData.length; ++i) {
            var item = recv.AryData[i];
            if (item.Symbol == symbol) {
                var aryMinute = item.Data;
                var stockItem = { date: item.Date, minute: [], yclose: item.YClose, symbol: item.Symbol, name: item.Name };
                if (!Array.isArray(aryMinute)) continue;
                for (var j = 0; j < aryMinute.length; ++j) {
                    var subItem = aryMinute[j];
                    var minItem =
                    {
                        date: subItem.Date,
                        time: subItem.Time,
                        price: subItem.Price,
                        avprice: subItem.AvPrice,
                        open: subItem.Price,
                        low: subItem.Price,
                        high: subItem.Price,
                        vol: subItem.Vol,
                        amount: subItem.Amount
                    };

                    if (IFrameSplitOperator.IsNumber(subItem.Position)) minItem.position = subItem.Position;

                    stockItem.minute.push(minItem);
                }

                hqchartData.stock.push(stockItem);
            }
        }

        callback(hqchartData);
    }

    //单日分时图叠加
    Minute_RequestOverlayMinuteData(data, callback, option) {
        data.PreventDefault = true;
        var symbol = data.Request.Data.symbol;
        var date = data.Request.Data.days[0];

        if (option) {
            option.HQChart = data.Self;
            option.Symbol = symbol;
            option.Date = date;
        }

        var extendID = this.Counter++;

        var requestID = `${this.ID}-${extendID}`;

        var msg =
        {
            MessageID: 3,
            Data:
            {
                Type: 3,
                ID: requestID,
                ArySymbol: [{ Symbol: symbol, Date: date }],
                ExtendData: { ExtendID: extendID },
            }
        };

        var callbackInfo =
        {
            ID: requestID,
            ExtendID: extendID,
            Callback: (recv) => {
                this.Minute_RecvOverlayMinuteData(recv, callback, option);
            }
        }

        this.WSClient.Request(msg, callbackInfo);
    }


    Minute_RecvOverlayMinuteData(recv, callback, option) {
        var hqchart = null;
        if (option && option.HQChart) hqchart = option.HQChart;

        var symbol = option.Symbol;
        var hqchartData = { code: 0, symbol: symbol, name: symbol, data: [], ver: 2.0 };
        for (var i = 0; i < recv.AryData.length; ++i) {
            var item = recv.AryData[i];
            if (item.Symbol == symbol) {
                var aryMinute = item.Data;
                var stockItem = { date: item.Date, minute: [], yclose: item.YClose, symbol: item.Symbol, name: item.Name };
                for (var j = 0; j < aryMinute.length; ++j) {
                    var subItem = aryMinute[j];
                    var minItem = [];
                    minItem[0] = subItem.Time;
                    minItem[1] = subItem.Price;
                    minItem[2] = subItem.Price;
                    minItem[3] = subItem.Price;
                    minItem[4] = subItem.Price;
                    minItem[5] = subItem.Vol;
                    minItem[6] = subItem.Amount;
                    minItem[7] = subItem.AvPrice;
                    minItem[8] = subItem.Date;

                    stockItem.minute.push(minItem);
                }

                hqchartData.data.push(stockItem);
            }
        }

        callback(hqchartData);
    }



    KLine_RequestHistoryData(data, callback, option) {
        data.PreventDefault = true;
        var symbol = data.Request.Data.symbol;    //请求的股票代码
        var right = data.Request.Data.right;     //复权
        var period = data.Request.Data.period;    //周期
        var count = data.Request.Data.count;
        var first = data.Request.Data.first;

        if (!count) count = 420;
        var reqSeq = ++this.KLineReqSeq;

        console.log(`[StockData::KLine_RequestHistoryData] Symbol=${symbol}, Right=${right} Period=${period} Count=${count}`);

        // === K线数据缓存：全量请求（取最新 count 根），TTL 内命中直接返回，不发网络请求 ===
        var cachedAry = this.KLineCacheGet(symbol, period, right, count, null);
        if (cachedAry) {
            console.log(`[StockData::KLine_RequestHistoryData] 命中本地缓存, Count=${cachedAry.length}`);
            callback({ name: symbol, symbol: symbol, data: cachedAry, ver: 2.0 });
            return;
        }

        if (option) option.HQChart = data.Self;

        var extendID = this.Counter++;

        var symbolData = { Symbol: symbol, Period: period, Right: right, Count: count };
        if (first) symbolData.Range = { End: first };

        var msg =
        {
            MessageID: 3,
            Data:
            {
                Type: 100,
                ID: this.RequestKLineData_ID,
                ArySymbol: [symbolData],
                ExtendData: { ExtendID: extendID },
            }
        };

        var callbackInfo =
        {
            ID: this.RequestKLineData_ID,
            ExtendID: extendID,
            Callback: (recv) => {
                this.KLine_RecvHistoryData(recv, callback, option, { Symbol: symbol, Period: period, Right: right, Seq: reqSeq });
            }
        }

        this.WSClient.Request(msg, callbackInfo);
    }

    // 拖拽/缩放日K数据下载：请求 enddate 之前的 count 根日K数据
    KLine_RequestPreviousDayData(data, callback, option) {
        data.PreventDefault = true;
        var symbol = data.Request.Data.symbol;
        var right = data.Request.Right;       // period/right 在 Request 层，不在 Request.Data
        var period = data.Request.Period;
        var count = data.Request.Data.count;
        var endDate = data.Request.Data.enddate;  // 当前最早的K线日期 (YYYYMMDD 数字)

        if (!count) count = 640;
        var reqSeq = ++this.KLineReqSeq;
        console.log(`[StockData::KLine_RequestPreviousDayData] Symbol=${symbol}, Period=${period}, Count=${count}, EndDate=${endDate}`);

        // === K线数据缓存：历史范围请求（enddate 之前 count 根），历史数据不可变，无 TTL，覆盖即命中 ===
        var cachedPrev = this.KLineCacheGet(symbol, period, right, count, endDate);
        if (cachedPrev) {
            console.log(`[StockData::KLine_RequestPreviousDayData] 命中本地缓存, Count=${cachedPrev.length}, EndDate=${endDate}`);
            callback({ name: symbol, symbol: symbol, data: cachedPrev, ver: 2.0 });
            return;
        }

        if (option) option.HQChart = data.Self;

        var extendID = this.Counter++;
        var symbolData = { Symbol: symbol, Period: period, Right: right, Count: count };
        if (endDate) symbolData.Range = { End: endDate };

        var msg =
        {
            MessageID: 3,
            Data:
            {
                Type: 100,
                ID: this.RequestKLineData_ID,
                ArySymbol: [symbolData],
                ExtendData: { ExtendID: extendID },
            }
        };

        var callbackInfo =
        {
            ID: this.RequestKLineData_ID,
            ExtendID: extendID,
            Callback: (recv) => {
                this.KLine_RecvHistoryData(recv, callback, option, { Symbol: symbol, Period: period, Right: right, History: true, Seq: reqSeq });
            }
        }

        this.WSClient.Request(msg, callbackInfo);
    }

    // 拖拽/缩放分钟K数据下载：请求 enddate 之前的 count 根分钟K数据
    KLine_RequestPreviousMinuteData(data, callback, option) {
        data.PreventDefault = true;
        var symbol = data.Request.Data.symbol;
        var right = data.Request.Right;       // period/right 在 Request 层，不在 Request.Data
        var period = data.Request.Period;
        var count = data.Request.Data.count;
        var endDate = data.Request.Data.enddate;   // YYYYMMDD
        var endTime = data.Request.Data.endtime;    // HHMM

        if (!count) count = 640;
        var reqSeq = ++this.KLineReqSeq;
        // 组合 enddate+endtime 为 YYYYMMDDHHMM 格式
        var endDateTime = endDate;
        if (endDate && endTime != null) {
            endDateTime = parseInt(endDate) * 10000 + parseInt(endTime);
        }
        console.log(`[StockData::KLine_RequestPreviousMinuteData] Symbol=${symbol}, Period=${period}, Count=${count}, EndDateTime=${endDateTime}`);

        // === K线数据缓存：历史范围请求（enddate/endtime 之前 count 根），历史数据不可变，无 TTL，覆盖即命中 ===
        var cachedPrevM = this.KLineCacheGet(symbol, period, right, count, endDateTime);
        if (cachedPrevM) {
            console.log(`[StockData::KLine_RequestPreviousMinuteData] 命中本地缓存, Count=${cachedPrevM.length}, EndDateTime=${endDateTime}`);
            callback({ name: symbol, symbol: symbol, data: cachedPrevM, ver: 2.0 });
            return;
        }

        if (option) option.HQChart = data.Self;

        var extendID = this.Counter++;
        var symbolData = { Symbol: symbol, Period: period, Right: right, Count: count };
        if (endDateTime) symbolData.Range = { End: endDateTime };

        var msg =
        {
            MessageID: 3,
            Data:
            {
                Type: 100,
                ID: this.RequestKLineData_ID,
                ArySymbol: [symbolData],
                ExtendData: { ExtendID: extendID },
            }
        };

        var callbackInfo =
        {
            ID: this.RequestKLineData_ID,
            ExtendID: extendID,
            Callback: (recv) => {
                this.KLine_RecvHistoryData(recv, callback, option, { Symbol: symbol, Period: period, Right: right, History: true, Seq: reqSeq });
            }
        }

        this.WSClient.Request(msg, callbackInfo);
    }

    KLine_RecvHistoryData(recv, callback, option, reqInfo) {
        // 丢弃过期响应：快切周期时多个K线请求并发，响应按完成序送达无保证，
        // 旧响应后到会覆盖新数据（如初始420根旧响应覆盖切回后加载的更多数据）
        if (reqInfo && reqInfo.Seq != null && reqInfo.Seq !== this.KLineReqSeq) {
            console.log(`[StockData] 丢弃过期K线响应: seq=${reqInfo.Seq} < current=${this.KLineReqSeq}, ${reqInfo.Symbol} P${reqInfo.Period}`);
            return;
        }

        var hqchart = null;
        if (option && option.HQChart) hqchart = option.HQChart;

        console.log('[StockData.KLine_RecvHistoryData] 入口, recv.AryData=', recv.AryData && recv.AryData.length);
        var symbol = hqchart.Symbol;
        var hqchartData = { name: symbol, symbol: symbol, data: [], ver: 2.0 };
        var bFlowCapital = false;
        for (var i = 0; i < recv.AryData.length; ++i) {
            var item = recv.AryData[i];
            if (item.Symbol == symbol) {
                var aryKLine = item.Data;
                if (item.Name) hqchartData.name = item.Name;
                console.log('[StockData] FlowCapital check:', item.FlowCapital, 'Turnover:', item.Data && item.Data[0] && item.Data[0].Turnover);
                if (item.FlowCapital === true) bFlowCapital = true;
                if (IFrameSplitOperator.IsNonEmptyArray(aryKLine)) {
                    for (var j = 0; j < aryKLine.length; ++j) {
                        var item = aryKLine[j];
                        var kItem = [];
                        kItem[0] = item.Date;
                        kItem[1] = item.YClose;
                        kItem[2] = item.Open;
                        kItem[3] = item.High;
                        kItem[4] = item.Low;
                        kItem[5] = item.Close;
                    kItem[6] = item.Vol;
                    kItem[7] = item.Amount;
                    kItem[10] = item.Turnover;  //换手率
                    if (bFlowCapital) kItem[15] = item.FlowCapital;
                    if (IFrameSplitOperator.IsNumber(item.Position)) kItem[8] = item.Position;
                    if (IFrameSplitOperator.IsNumber(item.FClose)) kItem[9] = item.FClose;
                        hqchartData.data.push(kItem);
                    }
                }

                break;
            }
        }

        if (hqchart && bFlowCapital) hqchart.FlowCapitalReady = true;

        // === K线数据缓存：仅全量响应（终点=最新）写缓存；历史范围响应(History)终点非最新，不写 ===
        if (reqInfo && !reqInfo.History && hqchartData.data.length > 0
            && (!hqchart || hqchart.Symbol == reqInfo.Symbol)) {
            this.KLineCachePut(reqInfo.Symbol, reqInfo.Period, reqInfo.Right, hqchartData.data);
        }

        callback(hqchartData);
    }

    KLine_RequestRealtimeData(data, callback, option) {
        data.PreventDefault = true;
        var symbol = data.Request.Data.symbol[0];    //请求的股票代码
        var right = data.Request.Data.right;      //复权
        var period = data.Request.Data.period;    //周期
        var dateRange = data.Request.Data.dateRange;
        console.log(`[StockData::KLine_RequestHistoryData] Symbol=${symbol}, Right=${right} Period=${period}`);

        if (option) option.HQChart = data.Self;

        var extendID = this.Counter++;

        var msg =
        {
            MessageID: 3,
            Data:
            {
                Type: 100,
                ID: this.RequestKLineRealtimeData_ID,
                ArySymbol: [{ Symbol: symbol, Period: period, Right: right, Count: 3, DateRange: dateRange }],
                ExtendData: { ExtendID: extendID },
            }
        };

        //叠加股票数据
        for (var i = 1; i < data.Request.Data.symbol.length; ++i) {
            var symbol = data.Request.Data.symbol[i];
            msg.Data.ArySymbol.push({ Symbol: symbol, Period: period, Count: 3 });
        }

        var callbackInfo =
        {
            ID: this.RequestKLineRealtimeData_ID,
            ExtendID: extendID,
            Callback: (recv) => {
                this.KLine_RecvRealtimeData(recv, callback, option);
            }
        }

        this.WSClient.Request(msg, callbackInfo);

    }

    KLine_RecvRealtimeData(recv, callback, option) {
        var hqchart = null;
        if (option && option.HQChart) hqchart = option.HQChart;

        var symbol = hqchart.Symbol;
        var stockItem = { symbol: symbol, name: symbol, data: [] }
        var hqchartData = { stock: [stockItem], Ver: 3.0 };

        for (var i = 0; i < recv.AryData.length; ++i) {
            var item = recv.AryData[i];
            if (item.Symbol == symbol) {
                var aryKLine = item.Data;
                if (item.Name) stockItem.name = item.Name;
                if (IFrameSplitOperator.IsNonEmptyArray(aryKLine)) {
                    for (var j = 0; j < aryKLine.length; ++j) {
                        var item = aryKLine[j];
                        var kItem = [];
                        kItem[0] = item.Date;
                        kItem[1] = item.YClose;
                        kItem[2] = item.Open;
                        kItem[3] = item.High;
                        kItem[4] = item.Low;
                        kItem[5] = item.Close;
                        kItem[6] = item.Vol;
                        kItem[7] = item.Amount;
                        if (IFrameSplitOperator.IsNumber(item.Position)) kItem[8] = item.Position;

                        stockItem.data.push(kItem);
                    }
                }
            }
            else {
                var aryKLine = item.Data;
                var overlayStock = { symbol: item.Symbol, name: item.Symbol, data: [] };
                if (item.Name) overlayStock.name = item.Name;
                for (var j = 0; j < aryKLine.length; ++j) {
                    var item = aryKLine[j];
                    var kItem = [];
                    kItem[0] = item.Date;
                    kItem[1] = item.YClose;
                    kItem[2] = item.Open;
                    kItem[3] = item.High;
                    kItem[4] = item.Low;
                    kItem[5] = item.Close;
                    kItem[6] = item.Vol;
                    kItem[7] = item.Amount;

                    overlayStock.data.push(kItem);
                }

                hqchartData.stock.push(overlayStock);
            }
        }

        callback(hqchartData);
    }


    KLine_RequestHistoryMinuteData(data, callback, option) {
        data.PreventDefault = true;
        var symbol = data.Request.Data.symbol;    //请求的股票代码
        var right = data.Request.Data.right;     //复权
        var period = data.Request.Data.period;    //周期
        var count = data.Request.Data.count;
        var first = data.Request.Data.first;

        if (!count) count = 420;

        console.log(`[StockData::KLine_RequestHistoryMinuteData] Symbol=${symbol}, Right=${right} Period=${period} Count=${count}`);
        var reqSeq = ++this.KLineReqSeq;

        // === K线数据缓存：全量请求（取最新 count 根），TTL 内命中直接返回，不发网络请求 ===
        var cachedMinute = this.KLineCacheGet(symbol, period, right, count, null);
        if (cachedMinute) {
            console.log(`[StockData::KLine_RequestHistoryMinuteData] 命中本地缓存, Count=${cachedMinute.length}`);
            callback({ name: symbol, symbol: symbol, data: cachedMinute, ver: 2.0 });
            return;
        }

        if (option) option.HQChart = data.Self;

        var extendID = this.Counter++;

        var symbolData = { Symbol: symbol, Period: period, Right: right, Count: count };
        if (first) symbolData.Range = { End: first };

        var msg =
        {
            MessageID: 3,
            Data:
            {
                Type: 101,
                ID: this.RequestKLineMinuteData_ID,
                ArySymbol: [symbolData],
                ExtendData: { ExtendID: extendID },
            }
        };

        var callbackInfo =
        {
            ID: this.RequestKLineMinuteData_ID,
            ExtendID: extendID,
            Callback: (recv) => {
                this.KLine_RecvHistoryMinuteData(recv, callback, option, { Symbol: symbol, Period: period, Right: right, Seq: reqSeq });
            }
        }

        this.WSClient.Request(msg, callbackInfo);
    }

    KLine_RecvHistoryMinuteData(data, callback, option, reqInfo) {
        // 丢弃过期响应：与 KLine_RecvHistoryData 相同的序号守卫（分钟周期快切时旧响应后到会覆盖新数据）
        if (reqInfo && reqInfo.Seq != null && reqInfo.Seq !== this.KLineReqSeq) {
            console.log(`[StockData] 丢弃过期分钟K线响应: seq=${reqInfo.Seq} < current=${this.KLineReqSeq}, ${reqInfo.Symbol} P${reqInfo.Period}`);
            return;
        }

        var hqchart = null;
        if (option && option.HQChart) hqchart = option.HQChart;

        var symbol = hqchart.Symbol;
        var hqchartData = { name: symbol, symbol: symbol, data: [], ver: 2.0 };

        for (var i = 0; i < data.AryData.length; ++i) {
            var item = data.AryData[i];
            if (item.Symbol == symbol) {
                var aryKLine = item.Data;
                if (item.Name) hqchartData.name = item.Name;
                for (var j = 0; j < aryKLine.length; ++j) {
                    var item = aryKLine[j];
                    var kItem = [];
                    kItem[0] = item.Date;
                    kItem[1] = item.YClose;
                    kItem[2] = item.Open;
                    kItem[3] = item.High;
                    kItem[4] = item.Low;
                    kItem[5] = item.Close;
                    kItem[6] = item.Vol;
                    kItem[7] = item.Amount;
                    kItem[8] = item.Time;
                    if (IFrameSplitOperator.IsNumber(item.Position)) kItem[9] = item.Position;

                    hqchartData.data.push(kItem);
                }
                break;
            }
        }

        // === K线数据缓存：仅全量响应（终点=最新）写缓存；历史范围响应(History)终点非最新，不写 ===
        if (reqInfo && !reqInfo.History && hqchartData.data.length > 0
            && (!hqchart || hqchart.Symbol == reqInfo.Symbol)) {
            this.KLineCachePut(reqInfo.Symbol, reqInfo.Period, reqInfo.Right, hqchartData.data);
        }

        callback(hqchartData);
    }


    KLine_RequestMinuteRealtimeData(data, callback, option) {
        data.PreventDefault = true;
        var symbol = data.Request.Data.symbol[0];    //请求的股票代码
        var right = data.Request.Data.right;     //复权
        var period = data.Request.Data.period;    //周期
        var dateRange = data.Request.Data.dateRange;
        console.log(`[StockData::KLine_RequestHistoryMinuteData] Symbol=${symbol}, Right=${right} Period=${period}`);

        if (option) option.HQChart = data.Self;

        var extendID = this.Counter++;

        var msg =
        {
            MessageID: 3,
            Data:
            {
                Type: 101,
                ID: this.RequestKLineMinuteRealtimeData_ID,
                ArySymbol: [{ Symbol: symbol, Period: period, Right: right, Count: 3, DateRange: dateRange }],
                ExtendData: { ExtendID: extendID },
            }
        };

        //叠加股票数据
        for (var i = 1; i < data.Request.Data.symbol.length; ++i) {
            var symbol = data.Request.Data.symbol[i];
            msg.Data.ArySymbol.push({ Symbol: symbol, Period: period, Count: 3 });
        }

        var callbackInfo =
        {
            ID: this.RequestKLineMinuteRealtimeData_ID,
            ExtendID: extendID,
            Callback: (recv) => {
                this.KLine_RecvMinuteRealtimeData(recv, callback, option);
            }
        }

        this.WSClient.Request(msg, callbackInfo);
    }

    KLine_RecvMinuteRealtimeData(recv, callback, option) {
        var hqchart = null;
        if (option && option.HQChart) hqchart = option.HQChart;

        var symbol = hqchart.Symbol;
        var hqchartData = { name: symbol, symbol: symbol, data: [], ver: 2.0, overlay: [] };

        for (var i = 0; i < recv.AryData.length; ++i) {
            var item = recv.AryData[i];
            if (item.Symbol == symbol) {
                var aryKLine = item.Data;
                if (item.Name) hqchartData.name = item.Name;
                for (var j = 0; j < aryKLine.length; ++j) {
                    var item = aryKLine[j];
                    var kItem = [];
                    kItem[0] = item.Date;
                    kItem[1] = item.YClose;
                    kItem[2] = item.Open;
                    kItem[3] = item.High;
                    kItem[4] = item.Low;
                    kItem[5] = item.Close;
                    kItem[6] = item.Vol;
                    kItem[7] = item.Amount;
                    kItem[8] = item.Time;
                    if (IFrameSplitOperator.IsNumber(item.Position)) kItem[9] = item.Position;

                    hqchartData.data.push(kItem);
                }
            }
            else {
                var aryKLine = item.Data;
                var stockItem = { symbol: item.Symbol, name: item.Symbol, data: [] }
                if (item.Name) stockItem.name = item.Name;
                for (var j = 0; j < aryKLine.length; ++j) {
                    var item = aryKLine[j];
                    var kItem = [];
                    kItem[0] = item.Date;
                    kItem[1] = item.YClose;
                    kItem[2] = item.Open;
                    kItem[3] = item.High;
                    kItem[4] = item.Low;
                    kItem[5] = item.Close;
                    kItem[6] = item.Vol;
                    kItem[7] = item.Amount;
                    kItem[8] = item.Time;

                    stockItem.data.push(kItem);
                }

                hqchartData.overlay.push(stockItem);
            }
        }

        callback(hqchartData);
    }


    KLine_RequestOverlayHistoryData(data, callback, option) {
        data.PreventDefault = true;
        var symbol = data.Request.Data.symbol;
        var first = data.Request.Data.first;

        var symbol = data.Request.Data.symbol;    //请求的股票代码
        var period = data.Request.Data.period;    //周期
        console.log(`[StockData::KLine_RequestOverlayHistoryData] Symbol=${symbol}, Period=${period}`);

        if (option) {
            option.HQChart = data.Self;
            option.Symbol = symbol;
        }

        var extendID = this.Counter++;
        var requestID = `${this.ID}-${extendID}`;

        var msg =
        {
            MessageID: 3,
            Data:
            {
                Type: 100,
                ID: requestID,
                ArySymbol: [{ Symbol: symbol, Period: period, Count: 640 }],
                ExtendData: { ExtendID: extendID },
            }
        };

        var callbackInfo =
        {
            ID: requestID,
            ExtendID: extendID,
            Callback: (recv) => {
                this.KLine_RecvOverlayHistoryData(recv, callback, option);
            }
        }

        this.WSClient.Request(msg, callbackInfo);
    }

    KLine_RecvOverlayHistoryData(recv, callback, option) {
        var hqchart = null;
        if (option && option.HQChart) hqchart = option.HQChart;

        var symbol = option.Symbol;
        var hqchartData = { name: symbol, symbol: symbol, data: [], ver: 2.0 };

        for (var i = 0; i < recv.AryData.length; ++i) {
            var item = recv.AryData[i];
            if (item.Symbol == symbol) {
                var aryKLine = item.Data;
                if (item.Name) hqchartData.name = item.Name;
                for (var j = 0; j < aryKLine.length; ++j) {
                    var item = aryKLine[j];
                    var kItem = [];
                    kItem[0] = item.Date;
                    kItem[1] = item.YClose;
                    kItem[2] = item.Open;
                    kItem[3] = item.High;
                    kItem[4] = item.Low;
                    kItem[5] = item.Close;
                    kItem[6] = item.Vol;
                    kItem[7] = item.Amount;

                    hqchartData.data.push(kItem);
                }
                break;
            }
        }

        callback(hqchartData);
    }


    KLine_RequestOverlayHistoryMinuteData(data, callback, option) {
        data.PreventDefault = true;
        var symbol = data.Request.Data.symbol;
        var first = data.Request.Data.first;

        var symbol = data.Request.Data.symbol;    //请求的股票代码
        var period = data.Request.Data.period;    //周期
        console.log(`[StockData::KLine_RequestOverlayHistoryMinuteData] Symbol=${symbol}, Period=${period}`);

        if (option) {
            option.HQChart = data.Self;
            option.Symbol = symbol;
        }

        var extendID = this.Counter++;
        var requestID = `${this.ID}-${extendID}`;

        var msg =
        {
            MessageID: 3,
            Data:
            {
                Type: 101,
                ID: requestID,
                ArySymbol: [{ Symbol: symbol, Period: period, Count: 640 }],
                ExtendData: { ExtendID: extendID },
            }
        };

        var callbackInfo =
        {
            ID: requestID,
            ExtendID: extendID,
            Callback: (recv) => {
                this.KLine_RecvOverlayHistoryMinuteData(recv, callback, option);
            }
        }

        this.WSClient.Request(msg, callbackInfo);
    }


    KLine_RecvOverlayHistoryMinuteData(recv, callback, option) {
        var symbol = option.Symbol;
        var hqchartData = { symbol: symbol, name: symbol, ver: 2.0, data: [] };

        for (var i = 0; i < recv.AryData.length; ++i) {
            var item = recv.AryData[i];
            if (item.Symbol == symbol) {
                var aryKLine = item.Data;
                if (item.Name) hqchartData.name = item.Name;
                for (var j = 0; j < aryKLine.length; ++j) {
                    var item = aryKLine[j];
                    var kItem = [];
                    kItem[0] = item.Date;
                    kItem[1] = item.YClose;
                    kItem[2] = item.Open;
                    kItem[3] = item.High;
                    kItem[4] = item.Low;
                    kItem[5] = item.Close;
                    kItem[6] = item.Vol;
                    kItem[7] = item.Amount;
                    kItem[8] = item.Time;

                    hqchartData.data.push(kItem);
                }
                break;
            }
        }

        callback(hqchartData);
    }


    KLine_RequestFlowCapitalData(data, callback, option) {
        data.PreventDefault = true;
        var symbol = data.Request.Data.symbol[0];

        if (option) {
            option.HQChart = data.Self;
            option.Symbol = symbol;
        }

        var extendID = this.Counter++;
        var requestID = this.RequestKLineFlowCapitalData_ID;

        var msg =
        {
            MessageID: 3,
            Data:
            {
                Type: 200,
                ID: requestID,
                ArySymbol: [{ Symbol: symbol }],
                ExtendData: { ExtendID: extendID },
            }
        };

        var callbackInfo =
        {
            ID: requestID,
            ExtendID: extendID,
            Callback: (recv) => {
                this.KLine_RecvFlowCapitalData(recv, callback, option);
            }
        }

        this.WSClient.Request(msg, callbackInfo);
    }

    KLine_RecvFlowCapitalData(recv, callback, option) {
        var hqchartData = { stock: [], code: 0 };
        var hqchart = null;
        if (option && option.HQChart) hqchart = option.HQChart;

        var symbol = hqchart.Symbol;
        for (var i = 0; i < recv.AryData.length; ++i) {
            var item = recv.AryData[i];
            if (item.Symbol == symbol) {
                var stockItem = { stockday: [], symbol: symbol };
                if (IFrameSplitOperator.IsNonEmptyArray(item.Data)) {
                    for (var j = 0; j < item.Data.length; ++j) {
                        var subItem = item.Data[j];
                        if (!IFrameSplitOperator.IsNumber(subItem.ListA) || subItem.ListA <= 0) continue;
                        var newItem = { date: subItem.Date, capital: { a: subItem.ListA } };
                        stockItem.stockday.push(newItem);
                    }
                }

                hqchartData.stock.push(stockItem);
                break;
            }
        }

        callback(hqchartData);
    }


    KLine_INDEX_RequestData(data, callback, option) {
        data.PreventDefault = true;
        var period = data.Period;
        var symbol = data.Request.Data.symbol;
        var indexSymbol = "000001.sh";
        if (MARKET_SUFFIX_NAME.IsSHSZStockA(symbol)) {
            if (MARKET_SUFFIX_NAME.IsSH(symbol)) indexSymbol = "000001.sh";
            else if (MARKET_SUFFIX_NAME.IsSZ(symbol)) indexSymbol = "399001.sz";
        }
        var dateRange = data.Request.Data.dateRange;

        if (option) {
            option.HQChart = data.Self;
            option.IndexSymbol = indexSymbol;
            option.Symbol = symbol;
        }

        var extendID = this.Counter++;
        var requestID = `${this.ID}-${extendID}`;

        if (ChartData.IsMinutePeriod(period, true)) //分钟周期
        {
            var msg =
            {
                MessageID: 3,
                Data:
                {
                    Type: 101,
                    ID: requestID,
                    ArySymbol: [{ Symbol: indexSymbol, Period: period, Right: 0, Count: 640, Range: dateRange }],
                    ExtendData: { ExtendID: extendID },
                }
            };

            var callbackInfo =
            {
                ID: requestID,
                ExtendID: extendID,
                Callback: (recv) => {
                    this.KLine_INDEX_RecvMinuteData(recv, callback, option);
                }
            }
        }
        else if (ChartData.IsDayPeriod(period, true))    //日线周期
        {
            var msg =
            {
                MessageID: 3,
                Data:
                {
                    Type: 100,
                    ID: requestID,
                    ArySymbol: [{ Symbol: indexSymbol, Period: period, Right: 0, Count: 640, Range: dateRange }],
                    ExtendData: { ExtendID: extendID },
                }
            };

            var callbackInfo =
            {
                ID: requestID,
                ExtendID: extendID,
                Callback: (recv) => {
                    this.KLine_INDEX_RecvDayData(recv, callback, option);
                }
            }
        }
        else {
            return;
        }



        this.WSClient.Request(msg, callbackInfo);
    }


    KLine_INDEX_RecvDayData(recv, callback, option) {
        var indexSymbol = option.IndexSymbol;
        var hqchartData = this.JonsToKLine_DayData(indexSymbol, recv);

        callback(hqchartData);
    }

    KLine_INDEX_RecvMinuteData(recv, callback, option) {
        var indexSymbol = option.IndexSymbol;
        var hqchartData = this.JosnToKLine_MinuteData(indexSymbol, recv);

        callback(hqchartData);
    }

    KLine_RequestLatestData(data, callback, option) {
        data.PreventDefault = true;
        var symbol = data.Request.Data.symbol[0];
        if (option) {
            option.HQChart = data.Self;
        }

        var extendID = this.Counter++;
        var requestID = `${this.ID}-${extendID}`;

        var msg =
        {
            MessageID: 3,
            Data:
            {
                Type: 2,
                ID: requestID,
                ArySymbol: [{ Symbol: symbol, Fields: { ShareCapital: true } }],   //ShareCaptial 股本数据
                ExtendData: { ExtendID: extendID },
            }
        };

        var callbackInfo =
        {
            ID: requestID,
            ExtendID: extendID,
            Callback: (recv) => {
                this.KLine_RecvLatestDataV2(recv, callback, option);
            }
        }

        this.WSClient.Request(msg, callbackInfo);
    }


    KLine_RecvLatestDataV2(recv, callback, option) {
        var hqchart = null;
        if (option && option.HQChart) hqchart = option.HQChart;
        var symbol = hqchart.Symbol;
        var hqchartData = { code: 0, data: [], ver: 2.0 };
        var value = null;
        for (var i = 0; i < recv.AryData.length; ++i) {
            var stockItem = recv.AryData[i];
            if (stockItem.Symbol == symbol) {
                hqchartData.data.push({ id: 3, value: stockItem.YClose });  //DYNAINFO(3)  昨收盘价 即时行情数据 期货和期权品种为昨结算价
                hqchartData.data.push({ id: 4, value: stockItem.Open });    //DYNAINFO(4)  开盘价 即时行情数据 在开盘前,值为0,在使用时需要判断(否则分时指标时会影响纵坐标轴)   
                hqchartData.data.push({ id: 5, value: stockItem.High });    //DYNAINFO(5)  最高价 即时行情数据 在开盘前,值为0,在使用时需要判断(否则分时指标时会影响纵坐标轴)
                hqchartData.data.push({ id: 6, value: stockItem.Low });     //DYNAINFO(6)  最低价 即时行情数据 在开盘前,值为0,在使用时需要判断(否则分时指标时会影响纵坐标轴)
                hqchartData.data.push({ id: 7, value: stockItem.Close });   //DYNAINFO(7)  现价 即时行情数据 没有现价时(比如在开盘前),返回昨收盘价 盘中可能一直在变化,判断相等时须谨慎
                hqchartData.data.push({ id: 8, value: stockItem.Vol });     //DYNAINFO(8)  成交量 即时行情数据
                hqchartData.data.push({ id: 9, value: stockItem.LastTrade });     //DYNAINFO(9) 现量 即时行情数据
                hqchartData.data.push({ id: 10, value: stockItem.Amount });  //DYNAINFO(10) 总金额 即时行情数据

                //涨跌
                if (IFrameSplitOperator.IsNumber(stockItem.YClose) && IFrameSplitOperator.IsNumber(stockItem.Close)) {
                    value = stockItem.Close - stockItem.YClose;
                    hqchartData.data.push({ id: 12, value: value }); //DYNAINFO(12) 日涨跌 即时行情数据
                }

                //振幅
                if (IFrameSplitOperator.IsNumber(stockItem.Low) && IFrameSplitOperator.IsNumber(stockItem.High) && IFrameSplitOperator.IsNumber(stockItem.YClose) && stockItem.YClose != 0) {
                    value = (stockItem.High - stockItem.Low) / stockItem.YClose * 100;
                    hqchartData.data.push({ id: 13, value: value }); //DYNAINFO(13) 振幅 即时行情数据 转换成幅度需要乘100
                }

                //涨幅
                if (IFrameSplitOperator.IsNumber(stockItem.YClose) && stockItem.YClose != 0 && IFrameSplitOperator.IsNumber(stockItem.Close)) {
                    value = (stockItem.Close - stockItem.YClose) / stockItem.YClose * 100;
                    hqchartData.data.push({ id: 14, value: value }); //DYNAINFO(14) 涨幅 即时行情数据(沪深京早盘竞价期间使用匹配价的涨幅) 转换成幅度需要乘100
                }

                //买卖盘
                if (IFrameSplitOperator.IsNonEmptyArray(stockItem.Buys)) {
                    var BUY_PRICE_ID = [20, 71, 75, 79, 83], BUY_VOL_ID = [58, 72, 76, 80, 84]
                    for (var i = 0; i < stockItem.Buys.length && i < BUY_PRICE_ID.length; ++i) {
                        var item = stockItem.Buys[i];
                        if (IFrameSplitOperator.IsNumber(item.Price)) hqchartData.data.push({ id: BUY_PRICE_ID[i], value: item.Price });
                        if (IFrameSplitOperator.IsNumber(item.Vol)) hqchartData.data.push({ id: BUY_VOL_ID[i], value: item.Vol });
                    }
                }

                //卖盘
                if (IFrameSplitOperator.IsNonEmptyArray(stockItem.Sells)) {
                    var SELL_PRICE_ID = [21, 73, 77, 81, 85], SELL_VOL_ID = [59, 74, 78, 82, 86]
                    for (var i = 0; i < stockItem.Sells.length && i < SELL_PRICE_ID.length; ++i) {
                        var item = stockItem.Sells[i];
                        if (IFrameSplitOperator.IsNumber(item.Price)) hqchartData.data.push({ id: SELL_PRICE_ID[i], value: item.Price });
                        if (IFrameSplitOperator.IsNumber(item.Vol)) hqchartData.data.push({ id: SELL_VOL_ID[i], value: item.Vol });
                    }
                }

                hqchartData.data.push({ id: 22, value: stockItem.InVol });   //DYNAINFO(22) 返回内盘,板块指数则返回跌停家数 即时行情数据
                hqchartData.data.push({ id: 23, value: stockItem.OutVol });   //DYNAINFO(23) 返回外盘,板块指数则返回涨停家数 即时行情数据

                hqchartData.data.push({ id: 26, value: stockItem.UpLimit });    //DYNAINFO(26) 返回涨停价 即时行情数据
                hqchartData.data.push({ id: 27, value: stockItem.DownLimit });    //DYNAINFO(27) 返回跌停价 即时行情数据

                //DYNAINFO(37) 换手率(序列数据,每个周期的数据不同,使用的流通股本为最近数据) 转换成幅度需要乘100 比如DYNAINFO(37)>0.1表示换手超过10%
                //流通股的数据（股)
                if (stockItem.ShareCapital) {
                    var subItem = stockItem.ShareCapital;
                    if (IFrameSplitOperator.IsNumber(subItem.ListA)) hqchartData.data.push({ id: 37, value: subItem.ListA });
                }

                hqchartData.data.push({ id: 40, value: stockItem.PE_TTM });    //DYNAINFO(40) 市盈率(根据最近12个月的每股收益得到的市盈率) 即时行情数据 沪深京品种有效

                break;
            }

        }

        callback(hqchartData);
    }


    KLine_RequestOtherSymbolData(data, callback, option) {
        data.PreventDefault = true;
        var symbol = data.Request.Data.symbol;
        var period = data.Request.Data.period;
        var right = data.Request.Data.right;
        var dateRange = data.Request.Data.dateRange;

        if (option) {
            option.Symbol = symbol
        }

        var extendID = this.Counter++;
        var requestID = `${this.ID}-${extendID}`;

        if (ChartData.IsMinutePeriod(period, true)) //分钟周期
        {
            var msg =
            {
                MessageID: 3,
                Data:
                {
                    Type: 101,
                    ID: requestID,
                    ArySymbol: [{ Symbol: symbol, Period: period, Right: 0, Count: 640, Range: dateRange }],
                    ExtendData: { ExtendID: extendID },
                }
            };

            var callbackInfo =
            {
                ID: requestID,
                ExtendID: extendID,
                Callback: (recv) => {
                    this.KLine_RecvOtherSymbol_MinuteData(recv, callback, option);
                }
            }
        }
        else if (ChartData.IsDayPeriod(period, true))    //日线周期
        {
            var msg =
            {
                MessageID: 3,
                Data:
                {
                    Type: 100,
                    ID: requestID,
                    ArySymbol: [{ Symbol: symbol, Period: period, Right: 0, Count: 640, Range: dateRange }],
                    ExtendData: { ExtendID: extendID },
                }
            };

            var callbackInfo =
            {
                ID: requestID,
                ExtendID: extendID,
                Callback: (recv) => {
                    this.KLine_RecvOtherSymbol_DayData(recv, callback, option);
                }
            }
        }
        else {
            return;
        }

        this.WSClient.Request(msg, callbackInfo);

    }

    KLine_RecvOtherSymbol_DayData(recv, callback, option) {
        var symbol = null;
        if (option) symbol = option.Symbol;
        var hqchartData = this.JonsToKLine_DayData(symbol, recv);

        callback(hqchartData);
    }

    KLine_RecvOtherSymbol_MinuteData(recv, callback, option) {
        var symbol = null;
        if (option) symbol = option.Symbol;
        var hqchartData = this.JosnToKLine_MinuteData(symbol, recv);

        callback(hqchartData);
    }

    KLine_RequestSymbolData(data, callback, option) {
        data.PreventDefault = true;
        var symbol = data.Request.Data.symbol;
        var period = data.Request.Data.period;
        var right = data.Request.Data.right;
        var dateRange = data.Request.Data.dateRange;

        if (option) {
            option.Symbol = symbol;
        }

        var extendID = this.Counter++;
        var requestID = `${this.ID}-${extendID}`;

        if (ChartData.IsMinutePeriod(period, true)) //分钟周期
        {
            var msg =
            {
                MessageID: 3,
                Data:
                {
                    Type: 101,
                    ID: requestID,
                    ArySymbol: [{ Symbol: symbol, Period: period, Right: 0, Count: 640, Range: dateRange }],
                    ExtendData: { ExtendID: extendID },
                }
            };

            var callbackInfo =
            {
                ID: requestID,
                ExtendID: extendID,
                Callback: (recv) => {
                    this.KLine_RecvSymbol_DayData(recv, callback, option);
                }
            }
        }
        else if (ChartData.IsDayPeriod(period, true))    //日线周期
        {
            var msg =
            {
                MessageID: 3,
                Data:
                {
                    Type: 100,
                    ID: requestID,
                    ArySymbol: [{ Symbol: symbol, Period: period, Right: 0, Count: 640, Range: dateRange }],
                    ExtendData: { ExtendID: extendID },
                }
            };

            var callbackInfo =
            {
                ID: requestID,
                ExtendID: extendID,
                Callback: (recv) => {
                    this.KLine_RecvSymbol_MinuteData(recv, callback, option);
                }
            }
        }
        else {
            return;
        }

        this.WSClient.Request(msg, callbackInfo);
    }


    KLine_RecvSymbol_MinuteData(recv, callback, option) {
        var symbol = null;
        if (option) symbol = option.Symbol;
        var hqchartData = this.JosnToKLine_MinuteData(symbol, recv);

        callback(hqchartData);
    }

    KLine_RecvSymbol_DayData(recv, callback, option) {
        var symbol = null;
        if (option) symbol = option.Symbol;
        var hqchartData = this.JonsToKLine_DayData(symbol, recv);

        callback(hqchartData);
    }


    KLine_RequestVariantData(data, callback, option) {
        data.PreventDefault = true;
        var varName = data.Request.Data.VariantName;  //变量名称
        var symbol = data.Request.Data.symbol;
        var idData = this.GenerateUniqueID();

        //TOTALCAPITAL  当前总股本,单位为手,债券1手为10张,其它为100
        //CAPITAL       当前流通股本,单位为手,债券1手为10张,其它为100 对于可转债,为剩余规模(1000张)
        if (varName == "CAPITAL" || varName == "TOTALCAPITAL") {
            var msg =
            {
                MessageID: 3,
                Data:
                {
                    Type: 200, ID: idData.ID,
                    ArySymbol: [{ Symbol: symbol, Count: 1 }], ExtendData: { ExtendID: idData.ExtendID },
                }
            };

            if (option) {
                option.VariantName = varName;
                option.Symbol = symbol;
            }


            var callbackInfo =
            {
                ID: idData.ID,
                ExtendID: idData.ExtendID,
                Callback: (recv) => {
                    this.KLine_RecvVariant_Capital_Data(recv, callback, option);
                }
            }

            this.WSClient.Request(msg, callbackInfo);
        }

        else {
            var error = `变量'${varName}' 没有对接数据. [StockData::KLine_RequestVariantData]`;
            var hqchartData = { Error: error };
            callback(hqchartData);
        }

    }

    KLine_RecvVariant_Capital_Data(recv, callback, option) {
        var hqchartData = { DataType: 0, Data: null };
        var varName = null, symbol = null;
        if (option) {
            varName = option.VariantName;
            symbol = option.Symbol;
        }

        if (recv && IFrameSplitOperator.IsNonEmptyArray(recv.AryData)) {
            var stockItem = recv.AryData[0];
            if (stockItem && IFrameSplitOperator.IsNonEmptyArray(stockItem.Data) && stockItem.Data[0]) {
                if (stockItem.Symbol == symbol) {
                    var item = stockItem.Data[0];
                    if (varName == "CAPITAL") {
                        hqchartData.DataType = 1; //单值数据
                        hqchartData.Data = { Date: item.Date, Value: item.ListA / 100 }; //单位为手
                    }
                    else if (varName == "TOTALCAPITAL") {
                        hqchartData.DataType = 1; //单值数据
                        hqchartData.Data = { Date: item.Date, Value: item.Total / 100 }; //单位为手
                    }
                }
            }
        }

        callback(hqchartData);
    }


    KLine_RequestFinanceData(data, callback, option) {
        data.PreventDefault = true;
        var symbol = data.Request.Data.symbol;
        var id = data.Request.Data.id;
        var idData = this.GenerateUniqueID();

        //FINANCE(1) 总股本(序列数据,随时间每天可能变化)
        //FINANCE(7)  流通股本(序列数据,随时间每天可能变化)
        if (id == 1 || id == 7) {
            var msg =
            {
                MessageID: 3,
                Data:
                {
                    Type: 200, ID: idData.ID,
                    ArySymbol: [{ Symbol: symbol, Count: 120 }], ExtendData: { ExtendID: idData.ExtendID },
                }
            };

            if (option) {
                option.Symbol = symbol;
                option.FinanceID = id;
            }


            var callbackInfo =
            {
                ID: idData.ID,
                ExtendID: idData.ExtendID,
                Callback: (recv) => {
                    this.KLine_RecvFinanceData(recv, callback, option);
                }
            }

            this.WSClient.Request(msg, callbackInfo);
        }
        else {
            var error = `Finance(${id}) 没有对接数据. [StockData::KLine_RequestFinanceData]`;
            var hqchartData = { Error: error };
            callback(hqchartData);
        }
    }

    KLine_RecvFinanceData(recv, callback, option) {
        var financeID = 0;
        var symbol = null;
        if (option) {
            financeID = option.FinanceID;
            symbol = option.Symbol;
        }

        var aryData = []
        if (financeID == 1 || financeID == 7) {
            if (IFrameSplitOperator.IsNonEmptyArray(recv.AryData) && recv.AryData[0]) {
                var stockItem = recv.AryData[0];
                if (stockItem.Symbol = symbol && IFrameSplitOperator.IsNonEmptyArray(stockItem.Data)) {
                    for (var i = 0; i < stockItem.Data.length; ++i) {
                        var item = stockItem.Data[i];
                        var value = null;
                        if (!IFrameSplitOperator.IsNumber(item.Date)) continue;
                        if (financeID == 1) {
                            if (IFrameSplitOperator.IsNumber(item.Total)) value = item.Total;
                        }
                        else if (financeID == 7) {
                            if (IFrameSplitOperator.IsNumber(item.ListA)) value = item.ListA;
                        }

                        aryData.push({ Date: item.Date, Value: value });
                    }
                }
            }
        }

        callback(aryData);
    }

    //分价表
    Deal_Price_RequestHistoryData(data, callback, option) {
        data.PreventDefault = true;
        var symbol = data.Request.Data.symbol;

        var extendID = this.Counter++;
        var requestID = this.RequestDealData_ID;
        if (option) {

        }

        var msg =
        {
            MessageID: 3,
            Data:
            {
                Type: 6,
                ID: requestID,
                ArySymbol: [{ Symbol: symbol }], ExtendData: { ExtendID: extendID },
            }
        };

        if (option) {
            option.HQChart = data.Self;
        }

        var callbackInfo =
        {
            ID: requestID,
            ExtendID: extendID,
            Callback: (recv) => {
                this.Deal_Price_RecvHistoryData(recv, callback, option);
            }
        }

        this.WSClient.Request(msg, callbackInfo);
    }

    Deal_Price_RecvHistoryData(recv, callback, option) {
        var hqchart = null, symbol = null;
        if (option) hqchart = option.HQChart;
        if (hqchart) symbol = hqchart.Symbol;

        var hqchartData = { symbol: symbol, detail: [], yclose: null, UpdateType: 1 };
        if (recv && IFrameSplitOperator.IsNonEmptyArray(recv.AryData)) {
            for (var i = 0; i < recv.AryData.length; ++i) {
                var stockItem = recv.AryData[i];
                if (stockItem.Symbol == symbol) {
                    if (IFrameSplitOperator.IsNumber(stockItem.YClose)) hqchartData.yclose = stockItem.YClose;
                    if (IFrameSplitOperator.IsNonEmptyArray(stockItem.Data)) {
                        var maxRate = 0;
                        for (var j = 0; j < stockItem.Data.length; ++j) {
                            var priceItem = stockItem.Data[j];
                            var item = []
                            item[1] = priceItem.Price;
                            item[2] = priceItem.Vol;
                            item[101] = priceItem.BidRate;
                            item[102] = priceItem.Rate;
                            item[103] = priceItem.Vol;
                            if (maxRate < priceItem.Rate) maxRate = priceItem.Rate;
                            hqchartData.detail.push(item);
                        }

                        maxRate *= (1 + 0.1);
                        if (IFrameSplitOperator.IsPlusNumber(maxRate)) {
                            for (var j = 0; j < hqchartData.detail.length; ++j) {
                                var item = hqchartData.detail[j];
                                var price = item[1];
                                var colorIndex = 0;
                                if (price < hqchartData.yclose) colorIndex = 1;
                                else if (price == hqchartData.yclose) colorIndex = 2;
                                item[50] = { Value: [item[102] / maxRate], Color: [colorIndex] };
                            }
                        }

                    }

                    break;
                }


            }
        }

        callback(hqchartData);
    }

    //成交明细
    Deal_RequestHistoryData(data, callback, option) {
        data.PreventDefault = true;
        var symbol = data.Request.Data.symbol;
        var showType = 0;
        var count = 50;
        if (option) {
            if (IFrameSplitOperator.IsNumber(option.Count)) count = option.Count;
            if (IFrameSplitOperator.IsNumber(option.ShowType)) showType = option.ShowType;
        }

        if (showType == 3 || showType == 2)    //分价表
        {
            this.Deal_Price_RequestHistoryData(data, callback, option);
            return;
        }

        var extendID = this.Counter++;
        var requestID = this.RequestDealData_ID;
        var dataType = 4;
        if (showType == 1) dataType = 5;
        var msg =
        {
            MessageID: 3,
            Data:
            {
                Type: dataType,
                ID: requestID,
                ArySymbol: [{ Symbol: symbol, Count: count }], ExtendData: { ExtendID: extendID },
            }
        };

        if (option) {
            option.HQChart = data.Self;
        }

        var callbackInfo =
        {
            ID: requestID,
            ExtendID: extendID,
            Callback: (recv) => {
                this.Deal_RecvHistoryData(recv, callback, option);
            }
        }

        this.WSClient.Request(msg, callbackInfo);
    }


    Deal_RecvHistoryData(recv, callback, option) {
        var hqchart = null, symbol = null;
        if (option) hqchart = option.HQChart;
        if (hqchart) symbol = hqchart.Symbol;

        var hqchartData = this.JsonToDetailData(symbol, recv);
        callback(hqchartData);
    }

    Deal_RequestUpdateData(data, callback, option) {
        data.PreventDefault = true;
        var symbol = data.Request.Data.symbol;
        var showType = 0;
        if (option && IFrameSplitOperator.IsNumber(option.ShowType)) showType = option.ShowType;
        if (showType == 3 || showType == 2)    //分价表
        {
            this.Deal_Price_RequestHistoryData(data, callback, option);
            return;
        }

        var extendID = this.Counter++;
        var requestID = this.RequestDealData_ID;
        var tickData = data.Self.Data;
        var dataID = -1;
        if (tickData && IFrameSplitOperator.IsNonEmptyArray(tickData.Data)) dataID = tickData.Data[tickData.Data.length - 1].ID;

        var count = 10;
        if (option) {
            if (IFrameSplitOperator.IsNumber(option.Count)) count = option.Count;

            if (option.ShowType === 0) {
                count = 50;
                dataID = -1;
            }

            option.DataID = dataID;
        }

        var msg =
        {
            MessageID: 3,
            Data:
            {
                Type: 4, ID: requestID,
                ArySymbol: [{ Symbol: symbol, Count: count }], ExtendData: { ExtendID: extendID },
            }
        };

        if (option) {
            option.HQChart = data.Self;
        }


        var callbackInfo =
        {
            ID: requestID,
            ExtendID: extendID,
            Callback: (recv) => {
                this.Deal_RecvUpdateData(recv, callback, option);
            }
        }

        this.WSClient.Request(msg, callbackInfo);
    }

    Deal_RecvUpdateData(recv, callback, option) {
        var hqchart = null, symbol = null, startID = -1, showType = 0;
        if (option) {
            hqchart = option.HQChart;
            startID = option.DataID;
        }
        if (hqchart) symbol = hqchart.Symbol;


        var hqchartData = this.JsonToDetailData(symbol, recv);
        if (hqchartData && IFrameSplitOperator.IsNonEmptyArray(hqchartData.detail)) {
            var aryFilterData = [];
            for (var i = 0; i < hqchartData.detail.length; ++i) {
                var item = hqchartData.detail[i];
                if (item[6] > startID) aryFilterData.push(item);
            }

            hqchartData.detail = aryFilterData;
        }

        if (hqchartData && option && option.ShowType === 0) hqchartData.UpdateType = 1;

        callback(hqchartData);
    }


    JsonToDetailData(symbol, recv) {
        var hqchartData = { symbol: symbol, detail: [], yclose: null, yfclose: null };
        if (!recv || !IFrameSplitOperator.IsNonEmptyArray(recv.AryData)) return hqchartData;

        var upperSymbol = null;
        if (symbol) upperSymbol = symbol.toUpperCase();
        if (MARKET_SUFFIX_NAME.IsChinaFutures(upperSymbol)) //期货
        {
            for (var i = 0; i < recv.AryData.length; ++i) {
                var stockItem = recv.AryData[i];
                if (stockItem.Symbol == symbol) {
                    if (IFrameSplitOperator.IsNumber(stockItem.YClose)) hqchartData.yclose = stockItem.YClose;
                    if (IFrameSplitOperator.IsNumber(stockItem.YFClose)) hqchartData.yfclose = stockItem.YFClose;
                    if (IFrameSplitOperator.IsNonEmptyArray(stockItem.Data)) {
                        for (var j = 0; j < stockItem.Data.length; ++j) {
                            var tickItem = stockItem.Data[j];
                            var item = []
                            item[0] = tickItem.Time2;
                            item[1] = tickItem.Price;
                            item[2] = tickItem.Vol;
                            item[6] = tickItem.ID;

                            var color = null;
                            if (tickItem.Type == 1) color = "rgb(238,21,21)";       //开仓
                            else if (tickItem.Type == 2) color = "rgb(25,158,0)";   //平仓
                            item[201] = { Text: tickItem.PositionChange.toFixed(0), TextColor: color };
                            item[202] = { Text: tickItem.Flag, TextColor: color };

                            hqchartData.detail.push(item);
                        }
                    }
                    break;
                }
            }
        }
        else {
            for (var i = 0; i < recv.AryData.length; ++i) {
                var stockItem = recv.AryData[i];
                if (stockItem.Symbol == symbol) {
                    if (IFrameSplitOperator.IsNumber(stockItem.YClose)) hqchartData.yclose = stockItem.YClose;
                    if (IFrameSplitOperator.IsNonEmptyArray(stockItem.Data)) {
                        for (var j = 0; j < stockItem.Data.length; ++j) {
                            var tickItem = stockItem.Data[j];
                            var item = []
                            item[0] = tickItem.Time;
                            item[1] = tickItem.Price;
                            item[2] = tickItem.Vol;
                            item[3] = tickItem.Amount;
                            item[4] = tickItem.Type == "B" ? 1 : 2;
                            item[6] = tickItem.ID;

                            hqchartData.detail.push(item);
                        }
                    }
                    break;
                }
            }
        }

        return hqchartData;
    }

    //买卖5档
    StockInfo_RequestStockData(data, callback, option) {
        data.PreventDefault = true;
        var symbol = data.Request.Data.symbol;

        if (option) {
            option.HQChart = data.Self;
        }

        var extendID = this.Counter++;
        var requestID = this.RequestStockInfoData_ID;

        var msg =
        {
            MessageID: 3,
            Data:
            {
                Type: 2,
                ID: requestID,
                ArySymbol: [{ Symbol: symbol }],
                ExtendData: { ExtendID: extendID },
            }
        };

        var callbackInfo =
        {
            ID: requestID,
            ExtendID: extendID,
            Callback: (recv) => {
                this.StockInfo_RecvStockData(recv, callback, option);
            }
        }

        this.WSClient.Request(msg, callbackInfo);
    }

    StockInfo_RecvStockData(recv, callback, option) {
        var hqchart = null, symbol = null;
        if (option) hqchart = option.HQChart;
        if (hqchart) symbol = hqchart.Symbol;

        var hqchartData = this.JsonToStockInfo_StockData(symbol, recv);
        callback(hqchartData);
    }

    JsonToStockInfo_StockData(symbol, recv) {
        var hqchartData = { symbol: symbol, name: symbol, yclose: null, yfclose: null, data: [] };    //data:[ { Name:"", Value: }]
        if (!recv || !IFrameSplitOperator.IsNonEmptyArray(recv.AryData)) return hqchartData;

        for (var i = 0; i < recv.AryData.length; ++i) {
            var stockItem = recv.AryData[i];
            if (stockItem.Symbol == symbol) {
                var upperSymbol = null;
                if (symbol) upperSymbol = symbol.toUpperCase();
                if (IFrameSplitOperator.IsNumber(stockItem.YClose)) hqchartData.yclose = stockItem.YClose;
                if (IFrameSplitOperator.IsNumber(stockItem.YFClose)) hqchartData.yfclose = stockItem.YFClose;
                if (stockItem.Name) hqchartData.name = stockItem.Name;

                var volBase = 1;
                if (MARKET_SUFFIX_NAME.IsSHSZ(upperSymbol)) volBase = 100;
                if (IFrameSplitOperator.IsNonEmptyArray(stockItem.Buys)) {
                    var aryValue = [];
                    for (var j = 0; j < stockItem.Buys.length; ++j) {
                        var item = stockItem.Buys[j];
                        if (IFrameSplitOperator.IsPlusNumber(item.Price))
                            aryValue[j] = { Price: item.Price, Vol: item.Vol / volBase };
                        else
                            aryValue[j] = { Price: null, Vol: null };
                    }

                    hqchartData.data.push({ Name: "Buys", Value: aryValue });
                }

                if (IFrameSplitOperator.IsNonEmptyArray(stockItem.Sells)) {
                    var aryValue = [];
                    for (var j = 0; j < stockItem.Sells.length; ++j) {
                        var item = stockItem.Sells[j];
                        if (IFrameSplitOperator.IsPlusNumber(item.Price))
                            aryValue[j] = { Price: item.Price, Vol: item.Vol / volBase };
                        else
                            aryValue[j] = { Price: null, Vol: null };
                    }

                    hqchartData.data.push({ Name: "Sells", Value: aryValue });
                }

                hqchartData.data.push({ Name: "Symbol", Value: { Text: symbol } });
                if (IFrameSplitOperator.IsNumber(stockItem.YClose)) hqchartData.data.push({ Name: "YClose", Value: { Value: stockItem.YClose } });
                if (IFrameSplitOperator.IsNumber(stockItem.Price)) hqchartData.data.push({ Name: "Price", Value: { Value: stockItem.Price } });
                if (IFrameSplitOperator.IsNumber(stockItem.Open)) hqchartData.data.push({ Name: "Open", Value: { Value: stockItem.Open } });
                if (IFrameSplitOperator.IsNumber(stockItem.High)) hqchartData.data.push({ Name: "High", Value: { Value: stockItem.High } });
                if (IFrameSplitOperator.IsNumber(stockItem.Low)) hqchartData.data.push({ Name: "Low", Value: { Value: stockItem.Low } });
                if (IFrameSplitOperator.IsNumber(stockItem.UpLimit)) hqchartData.data.push({ Name: "UpLimit", Value: { Value: stockItem.UpLimit } });
                if (IFrameSplitOperator.IsNumber(stockItem.DownLimit)) hqchartData.data.push({ Name: "DownLimit", Value: { Value: stockItem.DownLimit } });

                if (IFrameSplitOperator.IsNumber(stockItem.DownLimit)) hqchartData.data.push({ Name: "OutVol", Value: { Value: stockItem.OutVol / volBase } });  //转成手
                if (IFrameSplitOperator.IsNumber(stockItem.DownLimit)) hqchartData.data.push({ Name: "InVol", Value: { Value: stockItem.InVol / volBase } });    //转成手

                if (IFrameSplitOperator.IsNumber(stockItem.UpDown)) hqchartData.data.push({ Name: "UpDown", Value: { Value: stockItem.UpDown } });
                if (IFrameSplitOperator.IsNumber(stockItem.Increase)) hqchartData.data.push({ Name: "Increase", Value: { Value: stockItem.Increase } });

                if (IFrameSplitOperator.IsNumber(stockItem.Vol)) hqchartData.data.push({ Name: "Vol", Value: { Value: stockItem.Vol / volBase } }); //转成手
                if (IFrameSplitOperator.IsNumber(stockItem.Amount)) hqchartData.data.push({ Name: "Amount", Value: { Value: stockItem.Amount } });
                if (IFrameSplitOperator.IsNumber(stockItem.PE_TTM)) hqchartData.data.push({ Name: "PE_TTM", Value: { Value: stockItem.PE_TTM } }); //市盈率(TTM)
                if (IFrameSplitOperator.IsNumber(stockItem.PB)) hqchartData.data.push({ Name: "PB", Value: { Value: stockItem.PB } }); //市净率

                if (IFrameSplitOperator.IsNumber(stockItem.FlowMarketValue)) hqchartData.data.push({ Name: "FlowMarketValue", Value: { Value: stockItem.FlowMarketValue } });      //流通市值
                if (IFrameSplitOperator.IsNumber(stockItem.TotalMarketValue)) hqchartData.data.push({ Name: "TotalMarketValue", Value: { Value: stockItem.TotalMarketValue } });   //总市值
                if (IFrameSplitOperator.IsNumber(stockItem.Exchange)) hqchartData.data.push({ Name: "Exchange", Value: { Value: stockItem.Exchange } });       //换手率%
                if (IFrameSplitOperator.IsNumber(stockItem.Amplitude)) hqchartData.data.push({ Name: "Amplitude", Value: { Value: stockItem.Amplitude } });     //振幅%

                if (IFrameSplitOperator.IsNumber(stockItem.Position)) hqchartData.data.push({ Name: "Position", Value: { Value: stockItem.Position } });    //持仓量
                if (IFrameSplitOperator.IsNumber(stockItem.FClose)) hqchartData.data.push({ Name: "FClose", Value: { Value: stockItem.FClose } });    //结算价
                if (IFrameSplitOperator.IsNumber(stockItem.YFClose)) hqchartData.data.push({ Name: "YFClose", Value: { Value: stockItem.YFClose } });    //昨结算价

                break;
            }
        }

        return hqchartData;
    }

    //状态栏
    StatusBar_RequestStockData(data, callback, option) {
        data.PreventDefault = true;
        var aryStock = data.Request.Data.stocks;    //股票列表
        if (option) option.Report = data.Self;

        var arySymbol = [];
        for (var i = 0; i < aryStock.length; ++i) {
            arySymbol.push({ Symbol: aryStock[i].Symbol });
        }

        var extendID = this.Counter++;
        var requestID = this.RequestStockInfoData_ID;

        var msg =
        {
            MessageID: 3,
            Data:
            {
                Type: 1,
                ID: requestID,
                ArySymbol: arySymbol,
                ExtendData: { ExtendID: extendID },
            }
        };

        var callbackInfo =
        {
            ID: requestID,
            ExtendID: extendID,
            Callback: (recv) => {
                this.StatusBar_RecvStockData(recv, callback, option);
            }
        }

        this.WSClient.Request(msg, callbackInfo);
    }

    StatusBar_RecvStockData(recv, callback, option) {
        var hqchartData = this.JsonToStatusBar_StockData(recv);
        callback(hqchartData);
    }

    JsonToStatusBar_StockData(recv) {
        var hqchartData = { data: [] };
        if (!IFrameSplitOperator.IsNonEmptyArray(recv.AryData)) return hqchartData;

        for (var i = 0; i < recv.AryData.length; ++i) {
            var stockItem = recv.AryData[i];
            var item = { Symbol: stockItem.Symbol, Data: [] };
            item.YClose = stockItem.YClose;

            item.Data.push({ Key: "Name", Value: { Text: stockItem.Name } });          //名称
            item.Data.push({ Key: "Increase", Value: { Value: stockItem.Increase } });  //涨幅%
            item.Data.push({ Key: "UpDown", Value: { Value: stockItem.UpDown } });      //涨跌
            item.Data.push({ Key: "Amount", Value: { Value: stockItem.Amount } });      //成交额
            item.Data.push({ Key: "Price", Value: { Value: stockItem.Close } });        //价格

            hqchartData.data.push(item);
        }


        return hqchartData;
    }


    ///////////////////////////////////////////////////////////////////////////////////
    // 码表
    Keyboard_RequestSymbolList(data, callback, option) {
        var idData = this.GenerateUniqueID();

        var msg =
        {
            MessageID: 3,
            Data:
            {
                Type: 7, ID: idData.ID,
                AryMarket: [data.AryMarket], ExtendData: { ExtendID: idData.ExtendID },
            }
        };

        var callbackInfo =
        {
            ID: idData.ID,
            ExtendID: idData.ExtendID,
            Callback: (recv) => {
                this.Keyboard_RecvSymbolList(recv, callback, option);
            }
        }

        this.WSClient.Request(msg, callbackInfo);
    }

    Keyboard_RecvSymbolList(recv, callback, option) {
        var arySymbol = [];

        if (IFrameSplitOperator.IsNonEmptyArray(recv.AryData)) {
            for (var i = 0; i < recv.AryData.length; ++i) {
                var item = recv.AryData[i];
                var stockItem = { Symbol: item.Symbol, ShortSymbol: item.ShortSymbol, Name: item.Name, Type: item.Type, Data: { Symbol: item.Symbol, Type: item.Type, Market: item.Market } };
                var marketName = this.GetMarketName(item.Symbol);
                if (item.Type == 1) {
                    stockItem.TypeName = `${marketName}股票`;
                }
                else if (item.Type == 2) {
                    stockItem.TypeName = `${marketName}指数`;
                }
                else if (item.Type == 3) {
                    stockItem.TypeName = `${marketName}期货`;
                    stockItem.Color = "rgb(159, 61, 61)";
                }
                else if (item.Type == 4) {
                    stockItem.TypeName = `${marketName}期权`;
                    stockItem.Column = [null, { IsShow: false }];  //隐藏第2列
                    stockItem.Color = "rgb(0,144,255)";
                }


                arySymbol.push(stockItem);
            }
        }

        callback(arySymbol);
    }

    ///////////////////////////////////////////////////////////////////////////////////////////////////////////
    //T型报价
    //

    TReport_RequestStockListData(data, callback, option) {
        data.PreventDefault = true;
        var symbol = data.Request.Data.symbol;

        var extendID = this.Counter++;
        var requestID = this.RequestTReportListData_ID;

        var msg =
        {
            MessageID: 3,
            Data:
            {
                Type: 8,
                ID: requestID,
                ArySymbol: [{ Symbol: symbol }],
                ExtendData: { ExtendID: extendID },
            }
        };

        var callbackInfo =
        {
            ID: requestID,
            ExtendID: extendID,
            Callback: (recv) => {
                this.TReport_RecvStockListData(recv, callback, option);
            }
        }

        this.WSClient.Request(msg, callbackInfo);
    }

    TReport_RecvStockListData(recv, callback, option) {
        var hqchartData = { symbol: null, name: null, data: [] };

        if (recv && IFrameSplitOperator.IsNonEmptyArray(recv.AryData) && recv.AryData[0]) {
            var data = recv.AryData[0];
            hqchartData.symbol = data.Symbol;
            hqchartData.name = data.Name;
            if (IFrameSplitOperator.IsNonEmptyArray(data.AryData)) {
                for (var i = 0; i < data.AryData.length; ++i) {
                    var item = data.AryData[i];
                    //[2025.0, "HO2404-C-2025.CF", "HO2404-P-2025.CFE","HO2404-C-2025", "HO2404-P-2025"],
                    var newItem = [item.Price, null, null, null, null];
                    if (item.P) {
                        newItem[2] = item.P.Symbol;
                        newItem[4] = item.P.ShortSymbol;
                    }

                    if (item.C) {
                        newItem[1] = item.C.Symbol;
                        newItem[3] = item.C.ShortSymbol;
                    }

                    hqchartData.data.push(newItem);
                }
            }

            if (option && option.Underlying) {
                option.Underlying.Symbol = data.Underlying.Symbol;
                option.Underlying.Name = data.Underlying.Name;
            }
        }

        callback(hqchartData);
    }


    TReport_RequestStockData(data, callback, option) {
        var aryStock = data.Request.Data.stocks;    //列表
        data.PreventDefault = true;

        var arySymbol = [];
        for (var i = 0; i < aryStock.length; ++i) {
            arySymbol.push({ Symbol: aryStock[i] }); //MinuteClose=走势图线 KLine=k线图
        }

        if (option) {
            if (option.Underlying && option.Underlying.Symbol) arySymbol.push({ Symbol: option.Underlying.Symbol });

            option.Report = data.Self;
        }

        var extendID = this.Counter++;
        var requestID = this.RequestTReportStockData_ID;

        var msg =
        {
            MessageID: 3,
            Data:
            {
                Type: 1,
                ID: requestID,
                ArySymbol: arySymbol,
                ExtendData: { ExtendID: extendID },
            }
        };

        var callbackInfo =
        {
            ID: requestID,
            ExtendID: extendID,
            Callback: (recv) => {
                this.TReport_RecvStockData(recv, callback, option);
            }
        }

        this.WSClient.Request(msg, callbackInfo);
    }

    TReport_RecvStockData(recv, callback, option) {
        var hqchartData = { data: [], code: 0 };
        var report = null;
        if (option && option.Report) report = option.Report;

        function __Temp_CheckPriceChange(symbol, price, filedName, colID) {
            if (!symbol || !IFrameSplitOperator.IsNumber(price)) return false;
            if (!report) return false;
            if (!report.MapStockData.has(symbol)) return false;
            var stockItem = report.MapStockData.get(symbol);
            var value = stockItem[filedName]
            if (!IFrameSplitOperator.IsNumber(value)) return false;
            if (price === value) return false;

            var flashData = { ID: colID, Color: null, Count: 1 }; //4=最新价
            if (price > value) flashData.Color = "rgba(205,92,92,0.4)";
            else flashData.Color = "rgba(46,139,87,0.4)";

            report.SetFlashBGItem(symbol, flashData);
        }

        if (IFrameSplitOperator.IsNonEmptyArray(recv.AryData)) {
            //0=证券代码 1=股票名称 2=昨收 3=开 4=高 5=低 6=收 7=成交量 8=成交金额, 9=买价 10=买量 11=卖价 12=卖量 13=均价 14=持仓 16=涨停价 17=跌停价
            //21=涨幅% 22=涨跌 24=振幅% 
            //30=全局扩展数据  31=当前板块扩展数据
            // 101-110 数值
            var underlyingSymbol = option.Underlying.Symbol;
            for (var i = 0; i < recv.AryData.length; ++i) {
                var stockItem = recv.AryData[i];
                if (!stockItem) continue;
                if (stockItem.Symbol == underlyingSymbol) {
                    hqchartData.price = stockItem.Close; //标的最新价
                    continue;
                }

                var upperSymbol = stockItem.Symbol.toUpperCase();

                var item = [];
                item[0] = stockItem.Symbol;
                item[1] = MARKET_SUFFIX_NAME.GetShortSymbol(upperSymbol);

                item[2] = stockItem.YClose;             //昨收
                item[3] = stockItem.Open;               //今开
                item[4] = stockItem.High;               //最高
                item[5] = stockItem.Low;                //最低
                item[6] = stockItem.Close;              //最新价
                item[7] = stockItem.Vol;                //成交量
                item[8] = stockItem.Amount;             //成交额
                item[9] = stockItem.BidPrice;           //买一价
                item[10] = stockItem.BidVol;           //买量
                item[11] = stockItem.AskPrice;          //卖一价
                item[12] = stockItem.AskVol;            //卖量
                item[14] = stockItem.Position;            //持仓量
                item[35] = stockItem.Time;               //时间
                item[36] = stockItem.Date;               //日期

                item[21] = stockItem.Increase;           //涨幅%
                item[22] = stockItem.UpDown;             //涨跌
                item[24] = stockItem.Amplitude;          //振幅%

                item[38] = stockItem.Position;           //持仓量
                item[39] = stockItem.FClose;             //结算价
                item[40] = stockItem.YFClose;            //昨结算价

                __Temp_CheckPriceChange(stockItem.Symbol, stockItem.Close, "Price", TREPORT_COLUMN_ID.PRICE_ID);
                __Temp_CheckPriceChange(stockItem.Symbol, stockItem.BidPrice, "BuyPrice", TREPORT_COLUMN_ID.BUY_PRICE_ID);
                __Temp_CheckPriceChange(stockItem.Symbol, stockItem.AskPrice, "SellPrice", TREPORT_COLUMN_ID.SELL_PRICE_ID);

                hqchartData.data.push(item);
            }
        }

        callback(hqchartData);
    }

    //获取市场名称
    GetMarketName(symbol) {
        if (!symbol) return "";
        var upperSymbol = symbol.toUpperCase();
        if (MARKET_SUFFIX_NAME.IsSH(upperSymbol)) return "上海";
        else if (MARKET_SUFFIX_NAME.IsSZ(upperSymbol)) return "深圳";
        else if (MARKET_SUFFIX_NAME.IsBJ(upperSymbol)) return "北京";
        else if (MARKET_SUFFIX_NAME.IsHK(upperSymbol)) return "香港";
        else if (MARKET_SUFFIX_NAME.IsCFFEX(upperSymbol)) return "中金所";
        else if (MARKET_SUFFIX_NAME.IsSHFE(upperSymbol)) return "上海";
        else if (MARKET_SUFFIX_NAME.IsDCE(upperSymbol)) return "大连";
        else if (MARKET_SUFFIX_NAME.IsCZCE(upperSymbol)) return "郑州";
        else if (MARKET_SUFFIX_NAME.IsINE(upperSymbol)) return "上海";
        else return "";
    }

    ////////////////////////////////////////////////////////////////////////////////
    //
    //

    JosnToKLine_MinuteData(symbol, recv) {
        var hqchartData = { name: symbol, symbol: symbol, data: [], ver: 2.0 };
        if (!recv || !IFrameSplitOperator.IsNonEmptyArray(recv.AryData)) return hqchartData;

        for (var i = 0; i < recv.AryData.length; ++i) {
            var item = recv.AryData[i];
            if (item.Symbol == symbol) {
                var aryKLine = item.Data;
                if (item.Name) hqchartData.name = item.Name;
                for (var j = 0; j < aryKLine.length; ++j) {
                    var item = aryKLine[j];
                    var kItem = [];
                    kItem[0] = item.Date;
                    kItem[1] = item.YClose;
                    kItem[2] = item.Open;
                    kItem[3] = item.High;
                    kItem[4] = item.Low;
                    kItem[5] = item.Close;
                    kItem[6] = item.Vol;
                    kItem[7] = item.Amount;
                    kItem[8] = item.Time;

                    hqchartData.data.push(kItem);
                }
                break;
            }
        }

        return hqchartData;
    }

    JonsToKLine_DayData(symbol, recv) {
        var hqchartData = { name: symbol, symbol: symbol, data: [], ver: 2.0 };
        if (!recv || !IFrameSplitOperator.IsNonEmptyArray(recv.AryData)) return hqchartData;

        for (var i = 0; i < recv.AryData.length; ++i) {
            var item = recv.AryData[i];
            if (item.Symbol == symbol) {
                var aryKLine = item.Data;
                if (item.Name) hqchartData.name = item.Name;
                for (var j = 0; j < aryKLine.length; ++j) {
                    var item = aryKLine[j];
                    var kItem = [];
                    kItem[0] = item.Date;
                    kItem[1] = item.YClose;
                    kItem[2] = item.Open;
                    kItem[3] = item.High;
                    kItem[4] = item.Low;
                    kItem[5] = item.Close;
                    kItem[6] = item.Vol;
                    kItem[7] = item.Amount;

                    hqchartData.data.push(kItem);
                }
                break;
            }
        }

        return hqchartData;
    }


    GenerateUniqueID() {
        var extendID = this.Counter++;
        var requestID = `${this.ID}-${extendID}`;

        return { ID: requestID, ExtendID: extendID };
    }

}

//分时图交易时间区间修改
class HQTradeTime {
    static Inital() {
        JSChart.GetMinuteTimeStringData().CreateSHSZData = () => { return HQTradeTime.CreateSHSZData(); }  //替换交易时间段
        JSChart.GetMinuteTimeStringData().CreateBJData = () => { return HQTradeTime.CreateSHSZData(); }


        JSChart.GetMinuteCoordinateData().GetSHSZData = (upperSymbol, width) => { return HQTradeTime.GetSHSZData(upperSymbol, width); }    	//替换X轴刻度信息
        JSChart.GetMinuteCoordinateData().GetBJData = (upperSymbol, width) => { return HQTradeTime.GetSHSZData(upperSymbol, width); }
    }

    static CreateSHSZData() {
        var minuteStringData = JSChart.GetMinuteTimeStringData();

        const TIME_SPLIT =
            [
                { Start: 930, End: 1130 },
                { Start: 1300, End: 1500 }
            ];

        return minuteStringData.CreateTimeData(TIME_SPLIT);
    }

    static GetSHSZData(upperSymbol, width) {
        const SHZE_MINUTE_X_COORDINATE =
        {
            Full:   //完整模式
                [
                    [0, 0, "rgb(200,200,200)", "09:30"],
                    [31, 0, "RGB(200,200,200)", "10:00"],
                    [61, 0, "RGB(200,200,200)", "10:30"],
                    [91, 0, "RGB(200,200,200)", "11:00"],
                    [121, 1, "RGB(200,200,200)", "13:00"],
                    [151, 0, "RGB(200,200,200)", "13:30"],
                    [181, 0, "RGB(200,200,200)", "14:00"],
                    [211, 0, "RGB(200,200,200)", "14:30"],
                    [241, 1, "RGB(200,200,200)", "15:00"], // 15:00
                ],
            Simple: //简洁模式
                [
                    [0, 0, "rgb(200,200,200)", "09:30"],
                    [61, 0, "RGB(200,200,200)", "10:30"],
                    [121, 1, "RGB(200,200,200)", "13:00"],
                    [181, 0, "RGB(200,200,200)", "14:00"],
                    [241, 1, "RGB(200,200,200)", "15:00"]
                ],
            Min:   //最小模式     
                [
                    [0, 0, "rgb(200,200,200)", "09:30"],
                    [121, 1, "RGB(200,200,200)", "13:00"],
                    [241, 1, "RGB(200,200,200)", "15:00"]
                ],

            Count: 242,         //!! 一共的分钟数据个数，不要填错了
            MiddleCount: 120,   // Count/2 就可以。

            GetData: function (width) {
                if (width < 200) return this.Min;
                else if (width < 400) return this.Simple;

                return this.Full;
            }
        };

        return SHZE_MINUTE_X_COORDINATE;
    }
}


HQTradeTime.Inital();








